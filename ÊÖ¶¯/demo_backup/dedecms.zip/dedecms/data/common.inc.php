<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'demo_dede01';
$cfg_dbuser = 'root';
$cfg_dbpwd = '111111';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>