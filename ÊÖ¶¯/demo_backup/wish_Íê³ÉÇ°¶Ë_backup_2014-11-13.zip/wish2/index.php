<?php
define('APP_NAME','APP');
define('APP_PATH','./APP/');
define('APP_DEBUG',TRUE);
include './ThinkPHP/ThinkPHP.php';
?>