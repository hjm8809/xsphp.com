<?php
//Admin的function.php

?>