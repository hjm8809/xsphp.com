<?php
//Home的function.php	

?>