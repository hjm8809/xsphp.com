<?php
return array(
	//'配置项'=>'配置值'

	//分组配置
	'APP_GROUP_LIST'	=>	'Home,Admin',
	'DEFAULT_GROUP'	=>	'Home',
    // 'TMPL_EXCEPTION_FILE'   =>  './Public/Tpl/error.html',
	/* 数据库设置 */
    'DB_TYPE'               => 'mysql',     // 数据库类型
    'DB_HOST'               => 'localhost', // 服务器地址
    'DB_NAME'               => 'wish',          // 数据库名
    'DB_USER'               => 'root',      // 用户名
    'DB_PWD'                => '111111',          // 密码
    'DB_PORT'               => '',        // 端口
    'DB_PREFIX'             => 'hd_',    // 数据库表前缀

    //模板路径
    'TMPL_FILE_DEPR'       =>      '_',
);
?>