<?php
global $em_incomes;
$em_incomes = array();
$em_incomes['1'] = '低于1000元';
$em_incomes['2'] = '1000元以上';
$em_incomes['3'] = '2000元以上';
$em_incomes['4'] = '4000元以上';
$em_incomes['5'] = '8000元以上';
$em_incomes['6'] = '15000以上';
?>