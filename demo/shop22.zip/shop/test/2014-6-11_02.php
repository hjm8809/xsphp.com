<?php 
//是否预定义 $arr = array() 的区别实验;
	//A.预定义
$arr2 = array();
$arr2[] = 5; 
$arr2[] = 6; 
$arr2[] = 6; 
$arr2[] = 6; 
print_r($arr2); 
echo '<br />';
// $arr3 = array();
$arr3[] = 5;
$arr3[] = 6;
$arr3[] = 6;
$arr3[] = 6;
print_r($arr3);//
?>