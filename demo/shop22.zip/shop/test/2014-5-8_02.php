<?php 
/****
autoExecute(update)方法
****/

function autoExecute($table,$data,$mode,$where){
		//如果$mode == update,启用update方法
	if($mode == 'update'){
		//砌一个sql语句出来
		//updata from category 
		//set column1 = value1,...,where...
		$sql = 'update '.$table.' set ';
		foreach($data as $k=>$v){
			$sql.=$k.'="'.$v.'",';
		}
		$sql = rtrim($sql,',');
		$sql .= ' '.$where;
		return $sql;
	}
}
$data = array(
	'cat_id'=>1,
	'cat_name'=>'男装',
	'intro'=>'男装不错',
	'parent_id'=>0
	);
$table = 'category';
$where = 'where cat_id = 1';
$q =autoExecute($table,$data,'update',$where);
echo $q;
?>

