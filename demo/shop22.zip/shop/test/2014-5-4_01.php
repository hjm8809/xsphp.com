<?php 
/****
测试时间函数的用法
****/
// date_default_timezone_set("PRC");//设置默认时区,中国
echo time();
echo date('YmdHis',time());

?>

