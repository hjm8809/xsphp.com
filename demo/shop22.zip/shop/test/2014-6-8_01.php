<?php 
/****
call_user_func()
****/
echo time();
echo '<br />';
echo call_user_func('time');
?>