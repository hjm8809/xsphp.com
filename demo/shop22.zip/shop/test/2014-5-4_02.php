<?php 
/****
测试addslashes()函数的用法
addslashes — 使用反斜线引用字符串
string addslashes ( string $str )
****/
$sql = "insert into tname (column1) values ('\c')";
echo $sql,'<br />';//输出:insert into tname (column1) values ('\c')
echo addslashes($sql);//输出:insert into tname (column1) values (\'\\c\') ,\,'均被转义了

?>

