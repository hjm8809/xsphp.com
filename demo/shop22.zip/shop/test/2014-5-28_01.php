<?php 
/****
问题:return array() 会返回什么?

****/

$arr=array('一','二',3);
echo'hello';
return $arr[0];
echo '<br />';

?>