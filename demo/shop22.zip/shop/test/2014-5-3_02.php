<?php 
/****
测试mysql.class.php
****/

define('XXOO','XXOO的岁月');
echo XXOO;

// $mysql = new mysql();

?>

