<?php 
/****
测试addslashes()函数的用法
addslashes — 使用反斜线引用字符串
string addslashes ( string $str )
****/
// $a=ture;
1==1?print'1果然等于1':print'1竟然不等于1';
?>

