<?php 
/****
测试函数运行顺序
****/

	function query($sql){
			mysql_query($sql);
	}

// 找不到问题的错误
$conn = mysql_connect('localhost','root','');

mysql_select_db('shop',$conn);
$sql ="insert into test values('h','h')";
$result = query($sql,$conn);
var_dump($result);

/*
$conn = mysql_connect('localhost','root','');
mysql_select_db('shop',$conn);
$sql = "insert into test values('c','d')";
mysql_query($sql,$conn);
/*

/*
$conn = @mysql_connect("localhost","root","");
mysql_select_db("shop",$conn);

$sql ="insert into test values('a','b')";
mysql_query($sql,$conn);

*/
?>

