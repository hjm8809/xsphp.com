<?php 
/****
测试函数运行顺序
****/
$conn = @mysql_connect('localhost','root','');
mysql_select_db('shop',$conn);

$sql ="insert into test values('a','b')";
mysql_query($sql,$conn);

?>

