<?php 
/****
测试<input type="file" />功能
结论:得一键值对,值是字符串,不知道如何使用.
****/
var_dump($_POST);



?>