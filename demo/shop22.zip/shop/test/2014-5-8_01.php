<?php 
/****
测试 mysql_fetch_row()函数返回值
返回一行数组.
mysql_fetch_row()//返回[1]=>value;
mysql_fetch_assoc()返回['key_word']=>value
mysql_fetch_array()返回以上两条的组合数组;
****/
// $a=ture;
$conn = mysql_connect('localhost','root','');
$sql = 'set names gbk';
mysql_query($sql);
$sql = 'use shop';
mysql_query($sql);
$sql = 'select * from category'; 
$rs =mysql_query($sql);
$row = mysql_fetch_assoc($rs);
var_dump($row);
print_r($row);
?>

