<?php 
/****
var_dump_object实验
会返回什么?
答,返回:
  test Object
(
    [width] => 50
    [height:protected] => 80
    [item:protected] => Array
        (
            [0] => a
            [1] => b
            [2] => 555
        )

)

****/

class test{
	public $width = 50;
	protected $height = 80;
	protected $item = array('a','b',555);
	public function hello(){
		echo 'hello';
	}
	protected function hi(){
		echo 'hi';
	}
}

$test = new test();
// $test->hello();
var_dump($test);
print_r($test);

?>