<?php 
/****
如何直接访问类中的数组?
****/

class test{
	public $row = array();
	function test(){

		$CFG=array(
		'host'=>'localhost',
		'user'=>'root',
		'pwd'=>''
			);
	
	$this->row = $CFG;
	var_dump($CFG);
	echo '<br />';
	var_dump($this->row);
}
}

$test=new test();
var_dump($test->row['host']);

//结论:将数组直接赋值给变量,则变量会变成数组.
//对象只能访问 在其中的方法和属性.函数内部不允许访问.
//访问方式 :
// $test->row;访问属性
// $test->test();访问方法

?>
