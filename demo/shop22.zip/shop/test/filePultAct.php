<?php 
header('content-type:text/html;charset=utf-8;');
echo '<pre>';
/****
接收文件
A.并分目录存储
B.生成随机文件名

1: 根据时间戳,并按一定规则创建目录
2:获取文件后缀名
3:判断大小
****/


/*
计算并创建目录
返回目录
*/

function mk_dir(){
	$dir = date('md/i',time());
	if(is_dir('./'.$dir)){
		return $dir;
	}else{
		 mkdir('./'.$dir,0777,true);
		 return $dir;
	}
}
//2:获取文件后缀,返回字符串
function getExt($fileName){
	$tmp = explode('.',$fileName);
	return end($tmp);
}
//随机名字,返回字符串
function randName(){
	$str = 'abcdefghijklmnopqrstuvwxyz0123456789';
	return substr(str_shuffle($str),0,6);
}


//处理上传;
foreach($_FILES as $k=>$v){
$path = './'.mk_dir().'/'.randName().'.'.getExt($v['name']);

if($v['error']!=0){
	echo '上传失败';
	continue;
}
//移动
//多文件上传
$move = move_uploaded_file($v['tmp_name'],$path);
if($move){
	echo 'OK';
}else{
	echo 'NG';
}
}
/*


Array
(
    [avatar] => Array
        (
            [name] => temp.txt
            [type] => text/plain
            [tmp_name] => D:\wamp\tmp\phpB4.tmp
            [error] => 0
            [size] => 621
        )

    [hotpic] => Array
        (
            [name] => StormPlayer.exe
            [type] => application/octet-stream
            [tmp_name] => D:\wamp\tmp\phpB5.tmp
            [error] => 0
            [size] => 267648
        )

    [jianli] => Array
        (
            [name] => FileTips.dll
            [type] => application/qscall-plugin
            [tmp_name] => D:\wamp\tmp\phpB6.tmp
            [error] => 0
            [size] => 117632
        )

)


0=>文件上传成功。 
1=>上传的文件过大。 
2=>上传的文件过大。
3=>文件只有部分被上传。
4=>没有文件被上传。 
6=>找不到临时文件夹。
7=>文件写入失败。

*/
?>