<?php 
/****
测试array = 1;
与array[] =1;
的差异
****/

// $arr1 = array(a,b,c,d,e);
//$arr = x 与 $arr[] = x的区别实验;
$arr2 = array();
$arr2 = 5; 
$arr2 = 6; 
print_r($arr2); //6
echo '<br />';
$arr3 = array();
$arr3[] = 5;
$arr3[] = 6;
print_r($arr3);//Array ( [0] => 5 [1] => 6 ) 
/*总结 
A.$arr =x;
B.$arr[] = x;
A类,属于重新定义$arr,改变包括 数据类型与值;
B类,是正确的数组赋值.
*/
?>