<?php 
define('ACC',true);
require('../include/init.php');
$goods = new GoodsModel();
$data = $goods->gettrash();
include(ROOT.'view/admin/templates/trashlist.html');

?>