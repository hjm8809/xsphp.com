<?php 
/****
file trash.php
作用 逻辑删除商品//is_delete=1
****/
//开启权限控制
define('ACC',true);
//初始化
require('../include/init.php');

/*
思路:
接收数据
调用model
*/

$kid = $_GET['goods_id'] + 0;
// echo $kid;die;
if(empty($kid)){
	echo '商品不存在';
}
$goods = new GoodsModel();
$trash = $goods->trash($kid);
if($trash){
	echo '成功移入回收站';
}else{
	echo '移入回收站失败,或已移至回收站,请到数据库确认';
}

?> 