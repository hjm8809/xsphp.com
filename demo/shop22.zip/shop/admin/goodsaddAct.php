<?php 

define('ACC',true);
include('../include/init.php');

if(empty($_POST['goods_name'])){
	echo '请输入商品名称';
}
// print_r($_POST);echo 'aa<br />';
$_POST['goods_weight'] *=$_POST['weight_unit'];
/*
$data['goods_sn'] = $_POST['goods_sn'];
$data['goods_name'] = $_POST['goods_name'];
$data['market_price'] = $_POST['market_price'];
$data['shop_price'] = $_POST['shop_price'];
$data['goods_desc'] = $_POST['goods_desc'];
$data['goods_weight'] = $_POST['goods_weight']*$_POST['weight_unit'];
$data['is_best'] = $_POST['is_best'];
$data['is_new'] = $_POST['is_new'];
$data['is_hot'] = $_POST['is_hot'];
$data['is_on_sale'] = $_POST['is_on_sale'];
$data['goods_brief'] = $_POST['goods_brief'];
*/
$goods = new GoodsModel();
$facade = $goods->_facade($_POST);//过滤,删除多余
 // print_r($facade);DIE;
$_autoFill = $goods->_autoFill($facade);//填充,增加需要
//自动填充货号$sn
 if(empty($_autoFill['goods_sn'])){
 	$sn = $goods->createSn();
 	$_autoFill['goods_sn'] = $sn;
 }
$uptool = new UpTool();
$ori_img = $uptool->up('ori_img');
// echo ROOT.$ori_img;die;
if($ori_img){
	$_autoFill['ori_img'] = $ori_img;
}
//$_autoFill新增thumb_img字段.
$thumb = new ImageTool();
$thumb_img = $thumb->thumb(ROOT.$ori_img);
$thumb_goods_img = $thumb->thumb_goods(ROOT.$ori_img);
// var_dump($thumb_img);die;
$_autoFill['thumb_img']=$thumb_img;
$_autoFill['goods_img']=$thumb_goods_img;
// print_r($_autoFill);die;
$goods = $goods->add($_autoFill);
if($goods){
	echo '商品添加成功';
}else{
	echo '商品添加失败';
}
/*
Array ( 
[MAX_FILE_SIZE] => 2097152 
[goods_name] => 商品名称 
[goods_sn] => 商品货号
[cat_id] => 6 
[market_price] => 20
[shop_price] => 10 
[goods_desc] => 详细描述 
[goods_weight] => 商品重量 
[weight_unit] => 1 
[goods_number] => 100
[is_best] => 1
[is_new] => 1 
[is_hot] => 1
[is_on_sale] => 1
[keywords] => 商品重量
[goods_brief] => 商品重量
[seller_note] => 商品重量
[goods_id] => 0
[act] => insert
[$k] => insert )
*/
?>