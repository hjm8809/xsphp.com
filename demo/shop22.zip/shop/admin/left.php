<?php 
/****
file left.php
作用 
与index.html在同目录下
被index.html成功包含
****/
//开启权限控制
define('ACC',true);
//初始化
require('../include/init.php');
include(ROOT.'view/admin/templates/left.html');
?> 