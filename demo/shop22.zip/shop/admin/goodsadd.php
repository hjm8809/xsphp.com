<?php 
define('ACC',true);
require('../include/init.php');
$cateModel = new CateModel();
$catelist = $cateModel->select();
$catelist=$cateModel->getCatTree($catelist,0,$lev=1);
include(ROOT.'view/admin/templates/goodsadd.html');
?>