<?php 
/****
 file catedel.php
 作用:实现栏目页下的删除功能
****/
/*
思品:
接收cat_id
调用model
删除cat_id
*/

define('ACC',true);
require('../include/init.php');

$cat_id = $_GET['cat_id'] + 0;

$cat = new CateModel();
/*
//如果欲删除的栏目下有子栏目,则不允许删除
//思路:
无限级分类有3个基本应用
1.查子栏目
2.查子孙栏目 
3.查家谱树


我们可以在model里面写一个方法,专门查子栏目,
调用一下,并判断
*/
$getSon = $cat->getSon($cat_id);
if($getSon){
	exit('该栏目下有子栏目,不允许删除');
}

if($cat->delete($cat_id)){
	echo '删除成功';
}else{
	echo '删除失败';
}
?>