<?php 
/****
cateedit.php
作用:编辑栏目 
****/
/*
思路:
接收cat_id
实例化model
调用model取出栏目信息
展示到表单
*/
define('ACC',true);
include('../include/init.php');
$cat_id = $_GET['cat_id'] + 0;
$cateModel = new CateModel();
$cateinfo = $cateModel->find($cat_id);//返回关于$cat_id所在行[被编辑的产品数据]的数据数组
// print_r($cateinfo);

$catelist = $cateModel->select();
$catelist = $cateModel->getCatTree($catelist,0,1);
$parent_id = NULL;
include(ROOT.'view/admin/templates/cateedit.html');
?>