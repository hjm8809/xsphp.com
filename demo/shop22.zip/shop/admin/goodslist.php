<?php 
define('ACC',true);
require('../include/init.php');
$goods = new GoodsModel();
$data = $goods->getgoods();
include(ROOT.'view/admin/templates/goodslist.html');


// print_r($data);
/*
array (size=12)
  'goods_id' => string '1' (length=1)
  'goods_sn' => string '008' (length=3)
  'goods_name' => string '宫堡鸡丁3' (length=13)
  'shop_price' => string '15.00' (length=5)
  'market_price' => string '18.00' (length=5)
  'goods_weight' => string '0.800' (length=5)
  'goods_brief' => string '宫堡鸡丁' (length=12)
  'goods_desc' => string '宫堡鸡丁宫堡鸡丁' (length=24)
  'is_on_sale' => string '1' (length=1) 
  'is_best' => string '1' (length=1)
  'is_new' => string '1' (length=1)
  'is_hot' => string '1' (length=1)
*/
?>