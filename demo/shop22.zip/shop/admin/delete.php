<?php 
/****
file delete.php
作用 彻底删除 trashlist.php页面中的商品
****/

define('ACC',true);
include('../include/init.php');

$kid = $_GET['goods_id']+0;
if($kid == 0){
	echo'商品不存在';
}

$goods = new GoodsModel();
$delete = $goods->delete($kid);
if($delete){
	echo '彻底删除成功';
}else{
	echo '彻底删除失败';
}

?>