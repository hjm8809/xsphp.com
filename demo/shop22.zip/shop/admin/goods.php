<?php 
/****
file goods.php
作用 展示产品信息
****/

/*
思路
接收goods_id
实例化goodsModel
调用find方法
展示商品信息
*/
define('ACC',true);
include('../include/init.php');

$kid = $_GET['goods_id'] +0;
if(empty($kid)){
	echo '商品不存在';
}
$goods = new GoodsModel();
$find = $goods->find($kid);
print_r($find);
include(ROOT.'/view/front/shangpin.html');
//目前使用MVC模式,M与C已经实现,产品能正常显示,C暂停;
?>