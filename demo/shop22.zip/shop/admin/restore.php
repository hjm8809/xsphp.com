<?php 
/****
file restore.php
作用 恢复trash.php回收站中的商品
****/
define('ACC',true);
include('../include/init.php');

$kid = $_GET['goods_id']+0;
if($kid == 0){
	echo '商品不存在';
}

$goods = new GoodsModel();
$restore = $goods->restore($kid);
if($restore){
	echo '产品恢复成功';
}
else{
	echo '产品恢复失败';
}



?>