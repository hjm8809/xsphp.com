<?php 
/****
file cateeditAct.php
作用:处理cateedit.html表单
****/


//初始化
define('ACC',true);
require('../include/init.php');

$data = array();
//接$_POST,过滤
if(empty($_POST['cat_name'])){
	exit('分类名称不能为空');
}

$data['cat_name'] = $_POST['cat_name'];
$data['intro'] = $_POST['intro'];
$data['parent_id'] = $_POST['parent_id'];
$data['cat_id'] = $_POST['cat_id']+0;
// print_r($data);exit;

//调model,写入数据库
$update = new CateModel();

//功能改进:防止分类乱伦   新爹的儿子是他的祖先
//思路:假设欲将B类设为A类的子类  A父类 B子类
//则判断:A类是否B类的子孙类[写一个model[getTree()]遍历B的子孙树]
//若是,则提示:子孙乱伦,设置失败
$flag = true;
/*
$tree = $update->getTree($data['cat_id']);
// print_r($tree);die;
// echo $data['parent_id'];
foreach($tree as $v){
	if($v['cat_id'] == $data['parent_id']){
		echo '所选新父亲是你原来的儿子或者孙子,无法操作!';
		$flag = false;
	}
}
*/
if($update->getSon($data['cat_id'])){
		echo '所选新父亲是你原来的儿子或者孙子,无法操作!';
		$flag = false;
}
if($flag){
$u = $update->update($data,$data['cat_id']);
// var_dump($u);die;

if($u){
	echo '更新成功';
}else {
	echo '更新失败';
}
}


?>