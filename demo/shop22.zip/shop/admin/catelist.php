<?php 
/****
file catelist.php
作用 
与left.html在同目录下
left.html成功包含
****/
//开启权限控制
define('ACC',true);
//初始化
require('../include/init.php');

$cateModel = new CateModel();
$catelist = $cateModel->select();
// var_dump($catelist);exit;
// print_r($catelist);
$catelist = $cateModel->getCatTree($catelist,0,1);
// print_r($catelist);exit;


include(ROOT.'view/admin/templates/catelist.html');
?> 