<?php 
define('ACC',true);
require('../include/init.php');
/****
file cateaddAct.php
作用 接收cateadd.php表单页面发送来的数据
并调用model,所数据入库
****/

//第一步,接收数据
// print_r($_POST);

// 第二步,检验数据
$data = array();
//判断cat_id是否为空
if(empty($_POST['cat_name'])){
	exit('栏目名称不能为空');
}
$data['cat_name'] = $_POST['cat_name'];
//判断intro和父ID是否合法
$data['intro'] = $_POST['intro'];
//判断parent_id未设置的情况
if(!isset($_POST['parent_id'])){	
$data['parent_id'] = 0;
}else{
$data['parent_id'] = $_POST['parent_id'];
}
// print_r($data);

// 第三步,实例化model
// 调用model的相关方法

$cateModel = new CateModel();
if($cateModel->add($data)){
	echo '栏目添加成功';
}else{
	echo '栏目添加失败';
}


?>