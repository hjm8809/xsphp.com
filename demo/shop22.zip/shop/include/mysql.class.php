<?php 
defined('ACC')||exit('ACC Denied');
/*
file    mysql.class.php
MySQL数据库类 继承db.class.php

*/

class mysql extends db{

	//写单例模式
		private static $ins = NULL;
		private $conn = NULL;
		private $conf = array();

		 /*
	 	select_db()
	 	选择数据库
	 */ 
		public function select_db($dbname){
			$sql = 'use shop';
			$this->query($sql);
		}

	 /*
		setChar()
		选择字符集		
	 */
		public function setChar($char){
			$sql = 'set names '.$char;
			$this->query($sql);
		}
			//final protected 保护初始化函数
	final protected function __construct(){
		$this->conf = conf::getIns();//实例化conf类
		// return var_dump($this->conf);
		$h=$this->conf->host;
		$u=$this->conf->user;
		$p=$this->conf->pwd;
		$db=$this->conf->dbname;
		$char=$this->conf->char;

		$this->conn = $this->connect($h,$u,$p);
		$this->select_db($db);
		$this->setChar($char);

	}
	/*
		parm:无 直接调用即可
		return:对象
		功能:单例模式
	*/
	public static function getIns(){
		//一次运行,新对象,则创建
		if(!self::$ins instanceof self){
			return self::$ins = new self();
		}else{
			//如果不是第一次创建对象,则返回第一次创建的对象$ins
			return self::$ins;
		}
		
	}

	/*
	连接服务器
	parms $h 服务器地址
	parms $u 用户名
	parms $p 密码
	return bool
	*/		
	public function connect($h,$u,$p){
		return $this->conn = mysql_connect($h,$u,$p);
	}

	/*发送查询
	parms $sql 发送的sql语句
	return mixed bool/resource
	*/
	public function query($sql){
			$rs = mysql_query($sql);
			Log::write($sql);
			return $rs;
	}

	/*
	 查询单个数据
	 parms $sql 必须是select型语句
	 return 关联数组/bool
	*/
	 public function getRow($sql){
	 	$rs = $this->query($sql);
	 	$row = mysql_fetch_assoc($rs);
	 	return $row;
	 }

	/*
	查询多行数据
	parms $sql select型语句
	return array/bool
	*/
	public function getAll($sql){
		$rs = $this->query($sql);
		$arr=array();
		while($row = mysql_fetch_assoc($rs)){
			$arr[]=$row;
		}
		return $arr;
	}


	

	 /*
	自动执行insert/update语句
	parms $sql select型语句
	return array/bool
	 */
//--------
//业务逻辑不懂,只做了insert功能
	public function autoExecute($data,$table,$mode='insert',$where='where 1'){
		//array('t1'=>'aa','t2'=>'bb')
	//自动拼接成MySQL语句.
	//先写insert方法
		if(!is_array($data)){
			return false;
		}
		/*	
			param $data/$table/$mode
			return resource/bool
		*/
		if($mode == 'insert'){
			$key = NULL;
			$val = NULL;
		foreach($data as $k=>$v){
			//思路,将数组的$k,提出来,按(k1,k2,k3)格式重排
			if($key == null){
				$key =$k;
			}else{
				$key=$key.','.$k;
			}
			//思路,将数组的$v,提出来,按(v1,v2,v3)格式重排.痛苦的拼接	
			if($val == null){
				$val ="'".$v."'";
			}else{
				$val=$val.",'".$v."'";
			}
			}
			$sql = "insert into ".$table."(".$key.") values (".$val.")";
			return $this->query($sql);
		}
		//update()方法		
		//如果$mode == update,启用update方法
		/*
		param $table/$data/$mode/$where,
		return resource(update)
		*/
	if($mode == 'update'){
		//砌一个sql语句出来
		//updata from category 
		//set column1 = value1,...,where...
		$sql = "update $table set ";
		foreach($data as $k=>$v){
			$sql.="$k = '$v',";
		}
		$sql = rtrim($sql,',');
		$sql .= ' '.$where;
		return $this->query($sql);
	}
	}
//--------

	//返回受影响行数的方法
	public function affected_rows(){
		return mysql_affected_rows($this->conn);
		//返回最后一次执行时,数据库受影响行数
	}

	//返回上一次insert的ID
	public function insert_id(){
		return mysql_insert_id($this->conn);
	}
}

?>
