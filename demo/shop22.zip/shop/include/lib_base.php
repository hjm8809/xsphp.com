<?php
defined('ACC')||exit('ACC Denied');
/****
file:lib_base.php
作用:设置参数过滤函数_addslashes()
string addslashes ( string $str )
返回字符串，该字符串为了数据库查询语句等的需要在某些字符前加上了反斜线。
这些字符是单引号（'）、双引号（"）、反斜线（\）与 NUL（NULL 字符）。 
****/

//递归转义数组
function _addslashes($arr){
	foreach($arr as $k=>$v){
		if(is_string($v)){
			$arr['$k'] = addslashes($v);
		}elseif(is_array($v)){
			$arr['$k'] = _addslashes($v);
		}
	}return $arr;
}

?>