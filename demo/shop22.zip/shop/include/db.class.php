<?php 
defined('ACC')||exit('ACC Denied');
/*
file    db.class.php
数据库类

目前采用什么数据库,还不知道
*/
/*
	db类大纲:
	A.使用前提
		1)连接数据库 connect()
		2)统一字符集 setChar
		3)选库 select_db
		4)执行 query
	B.基础执行类型
		1)查 getRow getAll
		2)增/删/改 autoExecute
*/	
abstract class db{

	/*
	连接服务器
	parms $h 服务器地址
	parms $u 用户名
	parms $p 密码
	return bool
	*/		
	public abstract function connect($h,$u,$p);//连接||前提

	 /*
		setChar()
		选择字符集		
	 */
		public abstract function setChar($char);//选字符集||前提

	 /*
		select_db()
		选择数据库
	 */ 
		public abstract function select_db($dbname);//选库||前提

	/*发送查询
	parms $sql 发送的sql语句
	return mixed bool/resource
	*/
	public abstract function query($sql);//执行||前提

	/*
	 查询单个数据
	 parms $sql select型语句
	 return array/bool
	*/
	 public abstract function getRow($sql);//查||基础
	/*
	查询多行数据
	parms $sql select型语句
	return array/bool
	*/
	public abstract function getAll($sql);//查||基础


	 /*
	自动执行insert/update语句
	parms $sql select型语句
	return array/bool
	 */
	public abstract function autoExecute($table,$arr,$mode='insert');//增||基础
	// autoExecute('user',array('username'=>'zhansan','email'=>'zhang@163.com'),'insert');
	// 将发生 自动形成insert into user(username,email) values('zhansan','zhang@163.com')
}


?>