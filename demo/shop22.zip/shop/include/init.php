<?php 
defined('ACC')||exit('ACC Denied');
/****
file init.php
作用:框架初始化
****/
header('content-type:text/html;charset=utf-8;');
//开启session
//初始化当前的绝对路径
//换成正斜线的原因,WIN,LINUX均支持/,LINUX不支持\
$path = substr(str_replace('\\','/',__FILE__),0,-16);
// echo $path;die;//网站根目录
define('ROOT',$path);
// echo ROOT; //输出  D:/wamp/www/shop/
session_start();

//过滤参数,用递归的方式过滤$_GET,$POST,$COOKIE
include(ROOT.'include/lib_base.php');
$_GET = _addslashes($_GET);
$_POST = _addslashes($_POST);
$_COOKIE = _addslashes($_COOKIE);

//设置报错级别
define('DEBUG',false);
if(DEBUG){
	error_reporting(E_ALL);
}else{
	error_reporting(0);
}
/*
加载 
db.class.php   //数据库类
conf.class.php //配置文件类
*/
//inclue优先级:mysql最低,conf,log,db,相互独立
//mysql需要使用conf,log,db中的成员方法,
// require(ROOT.'include/conf.class.php');
// require(ROOT.'include/log.class.php');
// require(ROOT.'include/db.class.php');
// require(ROOT.'model/Model.class.php');
// require(ROOT.'model/TestModel.class.php');
// require(ROOT.'include/mysql.class.php');
//自动加载函数 __autoload(),
/*理论:
文件只加载两种目录,
ROOT/include/$class.class.php
ROOT/mocdel/$class.class.php
若需要用到时未加载,则自动加载
*/
include(ROOT.'include/mysmarty.class.php');
$smarty = new mysmarty();
spl_autoload_register('__initAutoload');
function __initAutoload($class){
	if(strtolower(substr($class,-5)) == 'model'){//将截取的内容统一小写对比
		require(ROOT.'model/'.$class.'.class.php');
	}else if(strtolower(substr($class,-4)) == 'tool'){
		require(ROOT.'tool/'.$class.'.class.php');
	}
	else{
		require(ROOT.'include/'.$class.'.class.php');
	}
}

?>