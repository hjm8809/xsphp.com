<?php 
defined('ACC')||exit('ACC Denied');
/*
file    mysmarty.class.php
作用 引入smarty.class.php文件并对常用设置进行初始化操作

*/
include(ROOT.'lib/smarty3/smarty.class.php');
/*
初始化内容:
a.模板路径
b.编译路径
c.缓存路径
d.开启缓存
*/
class mysmarty extends smarty{
	public function __construct(){
		parent::__construct();
		$this->template_dir = ROOT.'view/front';
		$this->compile_dir = ROOT.'data/comp';
		$this->cache_dir = ROOT.'data/cache';
		$this->caching = false;
	}
}

?>
