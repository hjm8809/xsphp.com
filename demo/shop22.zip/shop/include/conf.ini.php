<?php 
defined('ACC')||exit('ACC Denied');
/*
file    config.ini.php
配置文件
*/

$CFG = array();

$CFG['host'] = 'localhost';
$CFG['user'] = 'root';
$CFG['pwd'] = '111111';
$CFG['dbname'] = 'shop';
$CFG['char'] = 'utf8';

 
?>