<?php 
defined('ACC')||exit('ACC Denied');
/****
file log.class.php
作用:记录信息到日志
****/

/***
思路,给定内容,写入文件(fopen,fwrite...)
如果大于1M,旧文件重命名,新内容写入curr.txt
传给我一个内容,判断当前日志的大小
如果>1M,则备份日志
否则继续写入
***/

class Log{ 
	//建一个类常量,代表日志文件的名称
	const LOGFILE ='curr.log';
	//写日志
	public static function write($cont){
		$cont=date('Y-m-d H:i:s ',time()).$cont."\r\n";
		
		$log = self::isBack();//计算出日志文件的地址(到这一步,已完成文件创建)
		$fh = fopen($log,'ab');
		fwrite($fh,$cont);
		fclose($fh);

	}
	//备份日志(改名)
	public static function bak(){
		//把原来的日志文件,改名字,存储起来
		//改年-月-日格式
		$log = ROOT.'data/log/'.self::LOGFILE;
		date_default_timezone_set('UTC'+8);
		$bak = ROOT.'data/log/'.date('ymd').mt_rand(10000,99999).'bak';
		return rename($log,$bak);
	}

	//读取并判断日志大小,返回M为单位
	public static function isBack(){
		$log = ROOT.'data/log/'.self::LOGFILE;
		if(!file_exists($log)){
			//如果文件不存在,则创建该文件
			touch($log);//快速建立一个文件
			return $log;
		}
		//要是存在,则判断大小
		clearstatcache(true,$log);
		$size = filesize($log);
		if($size<=1024*1024){
			return $log;
		}
		//否则,返回
		if(!self::bak()){
			return $log;
		}else{
			touch($log);
			return$log;
		}
	}
}

?>