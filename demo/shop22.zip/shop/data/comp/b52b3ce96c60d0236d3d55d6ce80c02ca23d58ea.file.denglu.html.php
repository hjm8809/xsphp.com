<?php /* Smarty version Smarty-3.1.13, created on 2014-10-15 21:43:42
         compiled from "D:\wamp\www\shop\view\front\denglu.html" */ ?>
<?php /*%%SmartyHeaderCode:139715438f17a71f1b9-72028794%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b52b3ce96c60d0236d3d55d6ce80c02ca23d58ea' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\denglu.html',
      1 => 1413357262,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '139715438f17a71f1b9-72028794',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5438f17a756051_81246876',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5438f17a756051_81246876')) {function content_5438f17a756051_81246876($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<div class="block block1">
  当前位置: <a href="index.php">首页</a> <code>&gt;</code> 用户中心 <div class="blank"></div>


<div class="usBox clearfix">
  <div class="usBox_1 f_l">
   <div class="logtitle"></div>
   <div style="color:#999; padding:30px 20px 10px 30px;">已注册用户请从这里登录</div>
   <form method="post" action="login.php" name="formLogin">
        <table width="100%" cellspacing="5" cellpadding="3" border="0" align="left" class="user_table">
          <tbody><tr>
            <td width="15%" align="right">用户名</td>
            <td width="85%"><input type="text" class="inputBg" name="username" value=""></td>
          </tr>
          <tr>
            <td align="right">密码</td>
            <td>
            <input type="password" class="inputBg" name="passwd">
            </td>
          </tr>
                    <tr>
            <td colspan="2"><input type="checkbox" id="remember" name="remember" value="1"><label for="remember">记住用户名</label></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td align="left">
            <input type="hidden" value="act_login" name="act">
            <input type="hidden" value="http://www.zhongyis.com/category.php?id=17" name="back_act">
            <input type="submit" class="us_Submit" value="" name="submit">
            </td>
          </tr>
	  <tr><td></td>
      
      
      <td style="padding-top:80px;"><a class="f3" href="#">密码问题找回密码</a>&nbsp;&nbsp;&nbsp;<a class="f3" href="#">注册邮件找回密码</a></td></tr>
      </tbody></table>
    </form>
    <div class="blank"></div>
  </div>
  <div class="usTxt">
  <div class="regtitle"></div>
  <div style="padding-left:50px; padding-top:25px;">
    <p style="color:#999">如果您不是会员，请注册</p> <br>
    <strong class="f4">友情提示：</strong><br>
    不注册为会员也可在本店购买商品<br>
    但注册之后您可以：<br>
    1. 保存您的个人资料<br>
    2. 收藏您关注的商品<br>
    3. 享受会员积分制度<br>
    4. 订阅本店商品信息  <br>
    <a href="reg.php"><img src="./view/front/images/bnt_ur_reg.gif"></a>
  </div>
   </div>
</div>
<div class="blank"></div>
 <!-- 包含尾部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/footer.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>