<?php /* Smarty version Smarty-3.1.13, created on 2014-10-15 12:48:32
         compiled from "view\front\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:2926553b185ffd664f1-38669011%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'da0d87fcdb0f2e757e36e411747a858e09d3ca82' => 
    array (
      0 => 'view\\front\\footer.html',
      1 => 1401923424,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2926553b185ffd664f1-38669011',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b185ffd70b90_05165216',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b185ffd70b90_05165216')) {function content_53b185ffd70b90_05165216($_smarty_tpl) {?>       	<div class="help_lib">
            	<div class="help_cats clearfix">
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="新手上路" href="article_cat.php?id=5">新手上路</a></dt>
    <dd><a title="售后流程" href="article.php?id=9">售后流程</a></dd>
    <dd><a title="购物流程" href="article.php?id=10">购物流程</a></dd>
    <dd><a title="订购方式" href="article.php?id=11">订购方式</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="正装常识" href="article_cat.php?id=6">正装常识</a></dt>
    <dd><a title="面试着装十条军规" href="article.php?id=12">面试着装十条军规</a></dd>
    <dd><a title="学生如何挑选西服" href="article.php?id=13">学生如何挑选西服</a></dd>
    <dd><a title="九种打领带的方法" href="article.php?id=14">九种打领带的方法</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="配送与支付" href="article_cat.php?id=7">配送与支付</a></dt>
    <dd><a title="货到付款区域" href="article.php?id=15">货到付款区域</a></dd>
    <dd><a title="配送注意事项" href="article.php?id=16">配送注意事项</a></dd>
    <dd><a title="支付方式说明" href="article.php?id=17">支付方式说明</a></dd>
    <dd><a title="网上支付指南" href="article.php?id=73">网上支付指南</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="会员中心" href="article_cat.php?id=10">会员中心</a></dt>
    <dd><a title="资金管理" href="article.php?id=18">资金管理</a></dd>
    <dd><a title="我的收藏" href="article.php?id=19">我的收藏</a></dd>
    <dd><a title="我的订单" href="article.php?id=20">我的订单</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="服务保证" href="article_cat.php?id=8">服务保证</a></dt>
    <dd><a title="退换货原则" href="article.php?id=21">退换货原则</a></dd>
    <dd><a title="售后服务保证" href="article.php?id=22">售后服务保证</a></dd>
    <dd><a title="产品质量保证" href="article.php?id=23">产品质量保证</a></dd>
    <dd><a title="网购退换货说明" href="article.php?id=66">网购退换货说明</a></dd>
  </dl>
                    
                   <div class="help_tel"> 
                    <div class="t">订购热线（免长途费）</div>
                    <div class="b">400 647 1688</div> 
                    <div class="t">客户服务热线</div>
                    <div class="b">010-82866873 </div>
                   </div>
                    
                </div>
            </div>
 	
</div>
<div class="blank"></div>
<div style="text-align:center"></div>
<div class="page_footer block">
	<div class="foot_nav">
    	<div class="block">
             	<div class="nav_list">
                        <a href="#" style="padding:0 3px 0 5px">隐私保护</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">公司简介</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">联系我们</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">在线客服</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">加盟政策</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">团购优惠</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">配送方式</a>  
            
            
                         


</div></div></div></div></body></html><?php }} ?>