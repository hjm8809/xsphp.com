<?php /* Smarty version Smarty-3.1.13, created on 2014-06-30 16:16:52
         compiled from "D:\wamp\www\shop\view\front\smarty_index.html" */ ?>
<?php /*%%SmartyHeaderCode:1003753b11cf428b502-57505258%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '925455a7945cbdf96daed2a0663c631526ffbca5' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\smarty_index.html',
      1 => 1404116198,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1003753b11cf428b502-57505258',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'newlist' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b11cf430a144_21712541',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b11cf430a144_21712541')) {function content_53b11cf430a144_21712541($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<!-- <<?php ?>?php include(ROOT.'/view/front/header.html') ?<?php ?>> -->

<div class="block">
<div id="adSmall">
</div>
</div>
<div class="blank"></div><div class="block clearfix">
<div class="layout_1">
        <div class="layout_left">
        	<div class="lib_adv_1">
        	<a target="_blank" href="goods.php?id=63"><img src="http://www.zhongyis.com/data/afficheimg/20120831-0.jpg"></a>            </div>
            <div class="blank"></div>
            <div>
            	
                 
                
            </div>
        </div>
        <div class="layout_right">
            
        
<div class="shop_news">
            	<div class="lib_top">最新动态</div>
                <div class="lib_mid">
                	<ul class="listitem">
                    	                                                 <li>
                            <a title="中意斯创始人参加“达沃斯”论坛" href="article.php?id=69" style="color:#7f0019" target="_blank">中意斯创始人参加“达沃斯”论坛</a>
                            </li>
                         	
                          	
                                                	
                                                  
                          <li>
                            <a title="刘淇书记视察“中意斯”创业项目" href="article.php?id=64" target="_blank">刘淇书记视察“中意斯”创业项目</a>
                            </li>
                            	
                                                	
                                                  
                          <li>
                            <a title="中意斯正装获得诚信经营企业颁牌" href="article.php?id=63" target="_blank">中意斯正装获得诚信经营企业颁牌</a>
                            </li>
                            	
                                                	
                                                  
                          <li>
                            <a title="中意斯被评为北京青年创业之星" href="article.php?id=56" target="_blank">中意斯被评为北京青年创业之星</a>
                            </li>
                            	
                                                	
                                                  
                          <li>
                            <a title="阿根廷企业家联盟访问中意斯正装" href="article.php?id=55" target="_blank">阿根廷企业家联盟访问中意斯正装</a>
                            </li>
                            	
                                            </ul>
                </div>
                <div class="lib_down"></div>
            </div>
            <div class="blank"></div>
<div class="ad_weizhi"><table cellspacing="0" cellpadding="0">
<tbody><tr><td><a target="_blank" href="affiche.php?ad_id=65&amp;uri=http%3A%2F%2Fwww.zhongyis.com%2Fgoods.php%3Fid%3D305"><img width="235" height="124" border="0" src="./view/front/images/1346421362173851193.jpg"></a></td></tr>
</tbody></table></div>
<div class="ad_weizhi"><table cellspacing="0" cellpadding="0">
<tbody><tr><td><a target="_blank" href="affiche.php?ad_id=1&amp;uri=http%3A%2F%2Fwww.zhongyis.com%2Fgoods.php%3Fid%3D67"><img width="235" height="124" border="0" src="./view/front/images/1346421292612709323.jpg"></a></td></tr>
</tbody></table></div>
       
        </div>
    </div>
  
<div style="float:left;width:100%;" id="rec_best" class="shop_right_lib"><div class="np_index_content_part">
  <div id="itemNew" class="itemTit">
       <div><img src="./view/front/images/newtitle.gif"></div>
       <div class="more"><a href="#">更多请点击 &gt;&gt;</a></div>
  </div>
  
  
  
  <div class="blank"></div>
  
  <div class="lib_mid">
                	<div id="show_new_area" class="tabItem">
                                    	<div class="grid">
                                        <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['newlist']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>
                                        	<div class="goodsItem">
                        	<div class="goodsPic">
                        	<a class="preview" href="goods.php?goods_id=<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_id'];?>
"><img alt="<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['v']->value['thumb_img'];?>
"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_white" title="<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
" href="goods.php?goods_id=<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
</a></div>
                            	
                            	<span class="f_gray">市场价：</span><font class="f_market"><?php echo $_smarty_tpl->tpl_vars['v']->value['shop_price'];?>
</font><br>
                                中意价：<font class="f_shop"><?php echo $_smarty_tpl->tpl_vars['v']->value['market_price'];?>
</font>
                            </div>
                        </div>                                        	
                      <?php } ?>
                    </div>
                    					</div>                   
                </div>
</div></div>
<div class="blank"></div>
  
<div style="float:left;width:100%;" id="rec_best" class="shop_right_lib"><div class="np_index_content_part">
 <div id="itemBest" class="itemTit">
      <div><img src="./view/front/images/catt/42.jpg"></div>
      <div class="more"><a href="#">更多请点击 &gt;&gt;</a></div>
  </div>
  <div class="blank5"></div>
  <div class="cat_ads_box clearfix">
   <div class="f_l clearfix"><a target="_blank" href="goods.php?id=208"><img width="445" height="300" src="./view/front/images/1348884666066574567.jpg"></a></div>
   <div class="f_m clearfix"><a target="_blank" href="goods.php?id=299"><img width="280" height="300" src="./view/front/images/1348884756079050736.jpg"></a></div>
   <div class="f_r clearfix">
     <div id="cat_ads_slider_42" class="cat_ads_slider">
	   <dl>
	    	     <dt id="0"><p><a target="_blank" href="goods.php?id=212">枪驳大领面简约2扣女士正装/黑色</a></p></dt>
		 			     <dt id="1"><p><a target="_blank" href="goods.php?id=208">平驳圆领角简约1扣女士正装/黑色</a></p></dt>
		 			     <dt id="2"><p><a target="_blank" href="goods.php?id=116">一扣腰带装饰黑色女士西服套裤</a></p></dt>
		 			     <dt id="3"><p><a target="_blank" href="goods.php?id=210">平驳长领蕾丝花边贴袋1扣女士正装/黑色</a></p></dt>
		 			     <dt id="4"><p><a target="_blank" href="goods.php?id=205">精疏弹力棉暗竖纹修身女士正装衬衫/白色</a></p></dt>
		 			     <dt class="cur" id="5"><p><a target="_blank" href="goods.php?id=207">枪驳大领腰带时尚1扣女士正装/亮黑色</a></p></dt>
		 <dd class="5"><a target="_blank" href="goods.php?id=207"><img width="235" height="118" src="./view/front/images/1300608203444335551.jpg"></a></dd>			   </dl>
	 </div>
   </div>
  </div>
  <div class="blank"></div>
    <div class="lib_mid">                
                	<div class="tabItem">
                	<div class="grid">
                    
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=192"><img alt="纯白斜条棉涤女士衬衫2620" src="./view/front/images/192_thumb_G_1308279122357.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="纯白斜条棉涤女士衬衫2620" href="goods.php?id=192">纯白斜条棉涤女士衬衫2...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥84元</font><br>
                            	 中意价：<font class="f_shop">￥42元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=209"><img alt="枪驳大领面后开叉短款两扣女士正装GC18" src="./view/front/images/209_thumb_G_1301191658576.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="枪驳大领面后开叉短款两扣女士正装GC18" href="goods.php?id=209">枪驳大领面后开叉短款两...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥1198元</font><br>
                            	 中意价：<font class="f_shop">￥599元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=302"><img alt="双层青果领后腰褶摆一扣女士正装套裤/黑色GC22" src="./view/front/images/302_thumb_G_1346503936019.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="双层青果领后腰褶摆一扣女士正装套裤/黑色GC22" href="goods.php?id=302">双层青果领后腰褶摆一扣...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥998元</font><br>
                            	 中意价：<font class="f_shop">￥499元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=303"><img alt="泡泡袖后中衩一扣女士正装套裤/黑色GC23" src="./view/front/images/303_thumb_G_1346504995304.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="泡泡袖后中衩一扣女士正装套裤/黑色GC23" href="goods.php?id=303">泡泡袖后中衩一扣女士正...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥698元</font><br>
                            	 中意价：<font class="f_shop">￥349元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=305"><img alt="枪驳大领面简约2扣女士正装套裙/黑色815" src="./view/front/images/305_thumb_G_1346501380926.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="枪驳大领面简约2扣女士正装套裙/黑色815" href="goods.php?id=305">枪驳大领面简约2扣女士...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥998元</font><br>
                            	 中意价：<font class="f_shop">￥499元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                        
                    </div>
					</div>                   
                </div>
 </div></div>
<div class="blank"></div>
<div style="float:left;width:100%;" id="rec_best" class="shop_right_lib"><div class="np_index_content_part">
 <div id="itemBest" class="itemTit">
      <div><img src="./view/front/images/catt/17.jpg"></div>
      <div class="more"><a href="#">更多请点击 &gt;&gt;</a></div>
  </div>
  <div class="blank5"></div>
  <div class="cat_ads_box clearfix">
   <div class="f_l clearfix"><a target="_blank" href="goods.php?id=317"><img width="445" height="300" src="./view/front/images/1348884648769849359.jpg"></a></div>
   <div class="f_m clearfix"><a target="_blank" href="goods.php?id=227"><img width="280" height="300" src="./view/front/images/1348884740115473786.jpg"></a></div>
   <div class="f_r clearfix">
     <div id="cat_ads_slider_17" class="cat_ads_slider">
	   <dl>
	    	     <dt id="0"><p><a target="_blank" href="goods.php?id=65">三扣纯藏青色毛涤男士西装</a></p></dt>
		 			     <dt id="1"><p><a target="_blank" href="goods.php?id=66">两扣亮黑灰色男士小西服套装</a></p></dt>
		 			     <dt id="2"><p><a target="_blank" href="goods.php?id=70">一扣浅灰男士小西服单件</a></p></dt>
		 			     <dt id="3"><p><a target="_blank" href="goods.php?id=160">桑蚕丝纯蓝色暗格纹8cm窄领带</a></p></dt>
		 			     <dt id="4"><p><a target="_blank" href="goods.php?id=201">棉涤纯白男士衬衫</a></p></dt>
		 			     <dt class="cur" id="5"><p><a target="_blank" href="goods.php?id=181">纯白暗斜纹精梳棉修身衬衫</a></p></dt>
		 <dd class="5"><a target="_blank" href="goods.php?id=181"><img width="235" height="118" src="./view/front/images/1299582694587569387.jpg"></a></dd>			   </dl>
	 </div>
   </div>
  </div>
  <div class="blank"></div>
    <div class="lib_mid">                
                	<div class="tabItem">
                	<div class="grid">
                    
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=315"><img alt="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" src="./view/front/images/315_thumb_G_1346659439530.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" href="goods.php?id=315">两扣双开衩平驳头斜兜男...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥1598元</font><br>
                            	 中意价：<font class="f_shop">￥799元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=313"><img alt="纯羊毛一粒扣枪驳领纯黑西服套装" src="./view/front/images/313_thumb_G_1346420329070.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="纯羊毛一粒扣枪驳领纯黑西服套装" href="goods.php?id=313">纯羊毛一粒扣枪驳领纯黑...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥3980元</font><br>
                            	 中意价：<font class="f_shop">￥999元                                </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=317"><img alt="两扣单开衩枪驳领修身男士西服套装ZYS900/纯深藏青色/羊毛+涤纶" src="./view/front/images/317_thumb_G_1346661429032.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="两扣单开衩枪驳领修身男士西服套装ZYS900/纯深藏青色/羊毛+涤纶" href="goods.php?id=317">两扣单开衩枪驳领修身男...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥1398元</font><br>
                            	 中意价：<font class="f_shop">￥699元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=318"><img alt="两扣单开衩枪驳领修身男士西服套装ZYS6028/深藏青蓝条纹" src="./view/front/images/318_thumb_G_1346662515966.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="两扣单开衩枪驳领修身男士西服套装ZYS6028/深藏青蓝条纹" href="goods.php?id=318">两扣单开衩枪驳领修身男...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥1398元</font><br>
                            	 中意价：<font class="f_shop">￥699元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                       
     
                   		   <div class="goodsItem">
                        	<div class="goodsPic">
                            <a class="preview" href="goods.php?id=316"><img alt="两扣单开衩枪驳领斜兜男士西服套装ZW03/黑色条纹/纯羊毛" src="./view/front/images/316_thumb_G_1346660690951.jpg"></a>
                            </div>
                            <div class="goodsInfo">
                            	<div class="goodsSn"><a class="f_pname" title="两扣单开衩枪驳领斜兜男士西服套装ZW03/黑色条纹/纯羊毛" href="goods.php?id=316">两扣单开衩枪驳领斜兜男...</a></div>
                            	<span class="f_gray">市场价：</span><font class="f_market">￥2598元</font><br>
                            	 中意价：<font class="f_shop">￥1299元                                                                  </font>
                            </div>
                        </div>                   
                                    	
                    	
   
                        
                    </div>
					</div>                   
                </div>
 </div></div>
<div class="blank"></div>
<div class="blank"></div>	
<div class="blank"></div>

<!-- 包含尾部-->
<!--<<?php ?>?php include(ROOT.'/view/front/footer.html') ?<?php ?>>--><?php }} ?>