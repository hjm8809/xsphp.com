<?php /* Smarty version Smarty-3.1.13, created on 2014-10-11 16:36:46
         compiled from "view\front\msg.html" */ ?>
<?php /*%%SmartyHeaderCode:138535438fcf67f1b95-40479136%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9cc227ae9d394d3c19f607ce11bfa18aa126a141' => 
    array (
      0 => 'view\\front\\msg.html',
      1 => 1413045401,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '138535438fcf67f1b95-40479136',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5438fcf6828de3_57678277',
  'variables' => 
  array (
    'msg' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5438fcf6828de3_57678277')) {function content_5438fcf6828de3_57678277($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->

<?php echo $_smarty_tpl->getSubTemplate ("view/front/header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>




<div class="block">
  <div class="box">
   <div class="box_1">
    <h3><span>系统信息</span></h3>
    <div align="center" class="boxCenterList RelaArticle">
      <div style="margin:20px auto;">
      <p style="font-size: 14px; font-weight:bold; color: red;">
      <?php echo $_smarty_tpl->tpl_vars['msg']->value;?>

      </p>
        <div class="blank"></div>
     </div>
    </div>
   </div>
  </div>
</div>
<div class="blank"></div>
<div style="text-align:center"></div>

<div class="page_footer block">
	<div class="foot_nav">
    	<div class="block">
             	<div class="nav_list">


                        <a href="http://www.zhongyis.com/article.php?id=2" style="padding:0 3px 0 5px">隐私保护</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=5" style="padding:0 3px 0 5px">公司简介</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=4" style="padding:0 3px 0 5px">联系我们</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=3" style="padding:0 3px 0 5px">在线客服</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=1" style="padding:0 3px 0 5px">加盟政策</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=57" style="padding:0 3px 0 5px">团购优惠</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/myship.php" style="padding:0 3px 0 5px">配送方式</a>  
            
            
                         


</div></div></div></div></body>
</html><?php }} ?>