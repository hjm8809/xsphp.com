<?php /* Smarty version Smarty-3.1.13, created on 2014-10-11 17:22:45
         compiled from "view\front\test_smarty.html" */ ?>
<?php /*%%SmartyHeaderCode:104795438f4a0978c36-95832804%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '607d452936bb28fc157cf962a5736ca2ff96b0bf' => 
    array (
      0 => 'view\\front\\test_smarty.html',
      1 => 1413019363,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '104795438f4a0978c36-95832804',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5438f4a09b3350_91936418',
  'variables' => 
  array (
    'abc' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5438f4a09b3350_91936418')) {function content_5438f4a09b3350_91936418($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<title>新建网页</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="布尔教育 http://www.itbool.com" />
</head>
    <body>
    	abc
    	<?php echo $_smarty_tpl->tpl_vars['abc']->value['username'];?>

    </body>
</html><?php }} ?>