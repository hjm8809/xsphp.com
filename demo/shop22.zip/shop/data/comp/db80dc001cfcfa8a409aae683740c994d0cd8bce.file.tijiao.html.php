<?php /* Smarty version Smarty-3.1.13, created on 2014-10-24 17:58:03
         compiled from "D:\wamp\www\shop\view\front\tijiao.html" */ ?>
<?php /*%%SmartyHeaderCode:3248544a22ab193298-27487054%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'db80dc001cfcfa8a409aae683740c994d0cd8bce' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\tijiao.html',
      1 => 1402210934,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3248544a22ab193298-27487054',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_544a22ab1d6309_18848101',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_544a22ab1d6309_18848101')) {function content_544a22ab1d6309_18848101($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body>


<!-- 包含头部 -->
<<?php ?>?php include(ROOT . 'view/front/header.html'); ?<?php ?>>


<div class="blank"></div>

<div class="block">  
当前位置: <a href=".">首页</a> <code>&gt;</code> 购物流程 <div class="blank"></div>
  
                  <form onsubmit="return checkConsignee(this)" id="theForm" name="theForm" method="post" action="flow.php?act=done">
        <div class="flowBox">
<h6><span>收货人信息</span></h6>
<table width="100%" cellspacing="1" cellpadding="5" border="0" bgcolor="#dddddd" align="center">
    
  <tbody><tr>
    <td bgcolor="#ffffff">配送区域:</td>
    <td bgcolor="#ffffff" colspan="3">
    <input type="text" name="zone" />
    (必填) </td>
  </tr>
    <tr>
    <td bgcolor="#ffffff">收货人姓名:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="consignee_0" class="inputBg" name="reciver">
    (必填) </td>
    <td bgcolor="#ffffff">电子邮件地址:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="email_0" class="inputBg" name="email">
    (必填)</td>
  </tr>
    
  <tr>
    <td bgcolor="#ffffff">详细地址:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="address_0" class="inputBg" name="address">
    (必填)</td>
    <td bgcolor="#ffffff">邮政编码:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="zipcode_0" class="inputBg" name="zipcode"></td>
  </tr>
    <tr>
    <td bgcolor="#ffffff">电话:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="tel_0" class="inputBg" name="tel">
    (必填)</td>
    <td bgcolor="#ffffff">手机:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="mobile_0" class="inputBg" name="mobile"></td>
  </tr>
    
  <tr>
    <td bgcolor="#ffffff">标志建筑:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="sign_building_0" class="inputBg" name="building"></td>
    <td bgcolor="#ffffff">最佳送货时间:</td>
    <td bgcolor="#ffffff"><input type="text" value="" id="best_time_0" class="inputBg" name="best_time"></td>
  </tr>

</tbody></table>
</div> 

        <div class="flowBox">
        <h6><span>商品列表</span><a class="f6" href="flow.php">修改</a></h6>
        <table width="100%" cellspacing="1" cellpadding="5" border="0" bgcolor="#dddddd" align="center">
            <tbody><tr>
              <th bgcolor="#ffffff">商品名称</th>
              <th bgcolor="#ffffff">属性</th>
                            <th bgcolor="#ffffff">市场价</th>
                            <th bgcolor="#ffffff">本店价</th>
              <th bgcolor="#ffffff">购买数量</th>
              <th bgcolor="#ffffff">小计</th>
            </tr>
            <<?php ?>?php  foreach($items as $v) { ?<?php ?>>
                        <tr>
              <td bgcolor="#ffffff">
                        <a class="f6" target="_blank" href="goods.php?id=313"><<?php ?>?php echo $v['goods_name'];?<?php ?>></a>
                                                  </td>
              <td bgcolor="#ffffff">西服尺码:160/80A <br>
西裤尺码:72cm <br>
</td>
                            <td bgcolor="#ffffff" align="right">￥<<?php ?>?php echo $v['market_price'];?<?php ?>>元</td>
                            <td bgcolor="#ffffff" align="right">￥<<?php ?>?php echo $v['shop_price'];?<?php ?>>元</td>
              <td bgcolor="#ffffff" align="right"><<?php ?>?php echo $v['num'];?<?php ?>></td>
              <td bgcolor="#ffffff" align="right">￥<<?php ?>?php echo $v['num'] * $v['shop_price'];?<?php ?>>元</td>
            </tr>
             <<?php ?>?php } ?<?php ?>>
                                 <tr>
              <td bgcolor="#ffffff" colspan="7">
                            购物金额小计 ￥<<?php ?>?php echo $total;?<?php ?>>元，比市场价 ￥<<?php ?>?php echo $market_total;?<?php ?>>元 节省了 ￥<<?php ?>?php echo $discount;?<?php ?>>元 (<<?php ?>?php echo $rate;?<?php ?>>%)              </td>
            </tr>
                      </tbody></table>
      </div>
      <div class="blank"></div>
      
                <div class="flowBox">
    <h6><span>支付方式</span></h6>
    <table width="100%" cellspacing="1" cellpadding="5" border="0" bgcolor="#dddddd" align="center" id="paymentTable">
            <tbody><tr>
              <th width="5%" bgcolor="#ffffff">&nbsp;</th>
              <th width="20%" bgcolor="#ffffff">名称</th>
              <th bgcolor="#ffffff">订购描述</th>
              <th width="15%" bgcolor="#ffffff">手续费</th>
            </tr>
                        
            <tr>
              <td valign="top" bgcolor="#ffffff"><input type="radio" disabled="true" onclick="selectPayment(this)" iscod="1" value="3" name="payment"></td>
              <td valign="top" bgcolor="#ffffff"><strong>货到付款</strong></td>
              <td valign="top" bgcolor="#ffffff">开通城市：北京。 
货到付款区域：北京市内各高校</td>
              <td valign="top" bgcolor="#ffffff" align="right"><span id="ECS_CODFEE">￥0.00元</span></td>
            </tr>
                        
            <tr>
              <td valign="top" bgcolor="#ffffff"><input type="radio" onclick="selectPayment(this)" iscod="0" value="4" name="payment"></td>
              <td valign="top" bgcolor="#ffffff"><strong>网上支付</strong></td>
              <td valign="top" bgcolor="#ffffff">通过支付宝进行支付，无支付宝帐号的客户也可以用银行卡进行在线支付（前提是银行卡已经开通网上支付功能）。</td>
              <td valign="top" bgcolor="#ffffff" align="right">￥0.00元</td>
            </tr>
                      </tbody></table>
    </div>
                 

         

      
    <div class="blank"></div>
    <div class="flowBox">
    <h6><span>费用总计</span></h6>
          <div id="ECS_ORDERTOTAL">
<table width="100%" cellspacing="1" cellpadding="5" border="0" bgcolor="#e5e5e5" align="center">
    <tbody><tr>
    <td bgcolor="#ffffff" align="right">
       该订单完成后，您将获得                         <font class="f4_b">￥0.00元</font>的购物卡。
          </td>

  </tr>
    <tr>
    <td bgcolor="#ffffff" align="right">
      商品总价: <font class="f_orange_bold">￥<<?php ?>?php// echo $total; ?<?php ?>>元</font>
                                              </td>
  </tr>
    <tr>
    <td bgcolor="#ffffff" align="right"> 应付款金额: <font class="f_orange_bold">￥<<?php ?>?php// echo $total; ?<?php ?>>元</font>
  </td>
  </tr>
</tbody></table>
</div>           <div align="center" style="margin:8px auto;">
            <input type="image" src="./view/front/images/bnt_subOrder.gif">
            <input type="hidden" value="done" name="step">
            </div>
    </div>
    </form>
        
                



</div>
<div class="blank"></div>
<div style="text-align:center"></div>

<div class="page_footer block">
	<div class="foot_nav">
    	<div class="block">
             	<div class="nav_list">


                        <a href="article.php?id=2" style="padding:0 3px 0 5px">隐私保护</a>  
            
            
                          |
                                    <a href="article.php?id=5" style="padding:0 3px 0 5px">公司简介</a>  
            
            
                          |
                                    <a href="article.php?id=4" style="padding:0 3px 0 5px">联系我们</a>  
            
            
                          |
                                    <a href="article.php?id=3" style="padding:0 3px 0 5px">在线客服</a>  
            
            
                          |
                                    <a href="article.php?id=1" style="padding:0 3px 0 5px">加盟政策</a>  
            
            
                          |
                                    <a href="article.php?id=57" style="padding:0 3px 0 5px">团购优惠</a>  
            
            
                          |
                                    <a href="myship.php" style="padding:0 3px 0 5px">配送方式</a>  
            
            
                         


</div></div></div></div></body></html><?php }} ?>