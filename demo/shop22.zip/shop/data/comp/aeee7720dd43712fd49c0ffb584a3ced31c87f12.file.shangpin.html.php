<?php /* Smarty version Smarty-3.1.13, created on 2014-10-22 18:00:17
         compiled from "D:\wamp\www\shop\view\front\shangpin.html" */ ?>
<?php /*%%SmartyHeaderCode:20075543e11e2f036a3-17595921%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aeee7720dd43712fd49c0ffb584a3ced31c87f12' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\shangpin.html',
      1 => 1413971943,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20075543e11e2f036a3-17595921',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_543e11e2f20c69_12213958',
  'variables' => 
  array (
    'tree' => 0,
    'v' => 0,
    'g' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_543e11e2f20c69_12213958')) {function content_543e11e2f20c69_12213958($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<div class="block clearfix">
	<div class="layout_4">
        
        <div class="layout_right"> 
		         当前位置: <a href="index.php">首页</a>
             <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['tree']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
             <code>&gt;</code> <a href="#"><?php echo $_smarty_tpl->tpl_vars['v']->value['cat_name'];?>
</a>
              <?php } ?>
             <code>&gt;</code> <?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>

             <div class="blank"></div>
        
        	<div class="shop_right_lib_comm" style="border-top:1px solid #e6e6e6">
            	<div class="innerbox clearfix">
                	<div class="goods_info">
                    	<div class="polo_gallery f_l">
                          
					      <div class="goods_gallery">
                            	<div class="gup" id="gleft"></div>
                                <div class="gcontent" id="goods_gallery" style="overflow: hidden; width: 80px; height: 400px;">
                                	<table>
                                                                        <tbody><tr>
                                    <td><div class="curr"><a href="#" onmouseover="sw_goodsimg(this)"><img src="<?php echo $_smarty_tpl->tpl_vars['g']->value['thumb_img'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>
"></a></div></td>
                                    </tr>
                                                                        </tbody></table>
                                </div>
                                <div class="gdown" id="gright"></div>
                            </div>
        
                               <script type="text/javascript">								
								var goods_gallery=new Marquee("goods_gallery");
								goods_gallery.Direction="up";
								goods_gallery.Step=0;
								goods_gallery.Width=80;
								goods_gallery.Height=400;
								goods_gallery.Timer=20;
								var turnleft = document.getElementById("gleft");
								var turnright = document.getElementById("gright");
								goods_gallery.Start();
								turnleft.onmouseover=function(){goods_gallery.Direction=0}
								turnleft.onmouseout=turnleft.onmouseup=function(){goods_gallery.Step=goods_gallery.BakStep}
								turnleft.onmousedown=turnright.onmousedown=function(){goods_gallery.Step=goods_gallery.BakStep+10}
								turnright.onmouseover=function(){goods_gallery.Direction=1}
								turnright.onmouseout=turnright.onmouseup=function(){goods_gallery.Step=goods_gallery.BakStep}
							    </script> 
                      
	                              
                        </div>
                    	<div class="goods_pics_polo f_l">
                        	<div class="goods_big_img" style="position:relative; border:1px solid #e6e6e6">
                             <a href="#" class="jqzoom" id="picbox" style="outline-style: none; cursor: crosshair; display: block; height: 400px; width: 300px;" title="">                        	
                              <img src="<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_img'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>
" class="goodsimg" id="goods_bimg" style="position: absolute; top: 0px; left: 0px;" title="">                             </a>                             </div>
                             <a style="line-height:25px; display:block; width:400px; height:20px; text-align:center;" href="javascript:;" onclick="window.open('gallery.php?id=315'); return false;"><img src="./view/front/images/biao3.gif"> 点击查看大图</a>
                          
                             
                             
    		  </div>
                    	
                        <div class="goods_intro_polo f_r">
                        	<div class="textInfo">
     <form action="javascript:addToCart(315)" method="post" name="ECS_FORMBUY" id="ECS_FORMBUY">
		 <div class="clearfix" style="font-size:14px; font-weight:bold;  color:#333">
      <?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>
      
			</div>
      <ul>
       
        <li class="clearfix">
        <dd>
                 
        
            
       <div>
       <strong>商品货号：</strong><?php echo $_smarty_tpl->tpl_vars['g']->value['goods_sn'];?>
</div>
      
         
         </dd>
        </li> 
      
      
      
      
      
      
      
      
         
      
  
             
          
       
                   <li class="clearfix">
       <dd>
       <strong>本店售价：</strong><font class="shop1" id="ECS_SHOPPRICE"><?php echo $_smarty_tpl->tpl_vars['g']->value['shop_price'];?>
</font>
        </dd>
      </li>
                     <li class="clearfix">
       <dd>
       <strong style="color:#999">市场价格：</strong><font class="market"><?php echo $_smarty_tpl->tpl_vars['g']->value['market_price'];?>
</font>
         </dd>
      </li>
              
       
    
      
      
      
 
      
      
      
        <li class="clearfix price_line">
       <dd>
              
      <span> 
       
      <a style="color:#a10000" href="#">分享</a>  | 
        
      <a style="color:#a10000; padding-left:5px;" href="#">暂存</a>
      </span>
       </dd>
       </li>
      
      
     
  
                 
      
                   
            
            <li class="padd">
      <strong>尺码：</strong>
        
                                                                
                      
 <div class="catt">

  <!-- <a class="cattsel" onclick="changeAtt(this)" href="javascript:;" name="2782" title="[ ￥0.00元]">165/84A<input type="radio" style="display:none" id="spec_value_2782" name="spec_213" value="2782" checked=""></a> -->
  <a onclick="changeAtt(this)" href="javascript:;" name="2782" title="[ ￥0.00元]">165/84A<input type="radio" style="display:none" id="spec_value_2782" name="spec_213" value="2782" checked=""></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2783" title="[ ￥0.00元]">165/88B<input type="radio" style="display:none" id="spec_value_2783" name="spec_213" value="2783"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2784" title="[ ￥0.00元]">170/88A<input type="radio" style="display:none" id="spec_value_2784" name="spec_213" value="2784"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2785" title="[ ￥0.00元]">170/92B<input type="radio" style="display:none" id="spec_value_2785" name="spec_213" value="2785"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2786" title="[ ￥0.00元]">175/92A<input type="radio" style="display:none" id="spec_value_2786" name="spec_213" value="2786"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2787" title="[ ￥0.00元]">175/96B<input type="radio" style="display:none" id="spec_value_2787" name="spec_213" value="2787"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2788" title="[ ￥0.00元]">180/96A<input type="radio" style="display:none" id="spec_value_2788" name="spec_213" value="2788"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2789" title="[ ￥0.00元]">180/100B<input type="radio" style="display:none" id="spec_value_2789" name="spec_213" value="2789"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2790" title="[ ￥0.00元]">185/100A<input type="radio" style="display:none" id="spec_value_2790" name="spec_213" value="2790"></a>
  <a onclick="changeAtt(this)" href="javascript:;" name="2791" title="[ ￥0.00元]">185/104B<input type="radio" style="display:none" id="spec_value_2791" name="spec_213" value="2791"></a>
</div>
                        
                        
                        
                        <input type="hidden" name="spec_list" value="9">
                                                  </li>
         
      
      
      
      
      
      
      
      
      
       <li class="clearfix">
       <dd>
       <strong>用户评价：</strong>
      <img src="./view/front/images/stars5.gif" alt="comment rank 5">
       </dd>
      </li>
      
      
      
       
     
      </ul>
      
      
      
       <ul class="bnt_bg clearfix">
       <li>
       <div class="f_l">
<div style="_padding-top:17px;">
       购买数量：<input type="text" name="number" id="number" value="1" size="4" onblur="changePrice()" style="border:1px solid #ccc; width:40px;">
        </div>
       </div>
      <div class="f_l" style="padding-left:25px; border:none">
       <strong style=" font-weight: bold; color:#666; ">商品总价：</strong><font id="ECS_GOODS_AMOUNT" class="shop">￥799元</font>
      </div>
    <div class="f_r">
      <a href="./flow.php?act=buy&goods_id=<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_id'];?>
&num=1"><img src="./view/front/images/bnt_cat.gif"></a>
     </div> 
      </li>
      </ul>
      
      
      </form>
     </div>

                        </div>
                    </div>
                    <div class="blank"></div>
                    
                        
            <div class="tabs clearfix">
                        
                          <div class="tabItem f_l">
                            <div style="font-size:14px; color:#999; font-weight:bold; border-bottom:1px solid #bebebe; padding-bottom:8px; padding-top:10px;">商品说明</div>
                            <div class="blank"></div>
                            <div><?php echo $_smarty_tpl->tpl_vars['g']->value['goods_desc'];?>
</div>
                            </div>
                        </div>
                  
                    
       
                     
              </div>
            </div>

           <div class="layout_2 clearfix">
             <div class="layout_left">
         <div class="shop_left_lib" id="history_div" style="display: block;">
              <div class="lib_top">浏览历史</div>
                <div class="lib_mid" id="history_list">
                    <ul class="clearfix"><li class="goodsimg"><a href="#" target="_blank"><img src="./view/front/images/313_thumb_G_1346420329070.jpg" alt="纯羊毛一粒扣枪驳领纯黑西服套装" class="B_blue"></a></li><li><a href="#" target="_blank" title="纯羊毛一粒扣枪驳领纯黑西服套装">纯羊毛一粒扣枪驳领纯黑...</a><br>本店售价：<font class="f1">￥1099元</font><br></li></ul><ul class="clearfix"><li class="goodsimg"><a href="#" target="_blank"><img src="./view/front/images/315_thumb_G_1346659439530.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>
" class="B_blue"></a></li><li><a href="#" target="_blank" title="<?php echo $_smarty_tpl->tpl_vars['g']->value['goods_name'];?>
">两扣双开衩平驳头斜兜男...</a><br>本店售价：<font class="f1">￥799元</font><br></li></ul><ul id="clear_history"><a onclick="clear_history()">[清空]</a></ul>             
                </div>
                 <div class="lib_down"></div>
            </div>
            <div class="blank"></div>

             
             </div>
             <div class="layout_right">
            
             
             
          
             <div id="ECS_COMMENT"> <div class="box">
     <div class="box_1">
      <h3><span class="text">用户评论</span>(共<font class="f1">0</font>条评论)</h3>

 <div class="boxCenterList">


    <ul class="comments">
               <li>暂时还没有任何用户评论</li>
               </ul>



    <div class="blank5"></div>
      
      <div>
      <form action="javascript:;" onsubmit="submitComment(this)" method="post" name="commentForm" id="commentForm">
       <table width="710" cellspacing="5" cellpadding="0" border="0">
        <tbody><tr>
          <td width="64" align="right">用户名：</td>
          <td width="631">匿名用户</td>
        </tr>
        <tr>
          <td align="right">E-mail：</td>
          <td>
          <input type="text" name="email" id="email" maxlength="100" value="" class="inputBorder">
          </td>
        </tr>
        <tr>
          <td align="right">评价等级：</td>
          <td>
          <input type="radio" name="comment_rank" value="1" id="comment_rank1"> <img src="./view/front/images/stars1.gif">
          <input type="radio" name="comment_rank" value="2" id="comment_rank2"> <img src="./view/front/images/stars2.gif">
          <input type="radio" name="comment_rank" value="3" id="comment_rank3"> <img src="./view/front/images/stars3.gif">
          <input type="radio" name="comment_rank" value="4" id="comment_rank4"> <img src="./view/front/images/stars4.gif">
          <input type="radio" name="comment_rank" value="5" checked="checked" id="comment_rank5"> <img src="./view/front/images/stars5.gif">
          </td>
        </tr>
        <tr>
          <td valign="top" align="right">评论内容：</td>
          <td>
          <textarea name="content" class="inputBorder" style="height:50px; width:620px;"></textarea>
          <input type="hidden" name="cmt_type" value="0">
          <input type="hidden" name="id" value="315">
          </td>
        </tr>
        <tr>
          <td colspan="2">
                    <div style="padding-left:15px; text-align:left; float:left;">
          验证码：<input type="text" name="captcha" class="txt_style_1" style="width:50px; margin-left:5px;">
          <img align="absmiddle" src="./view/front/images/captcha.php" alt="captcha" onclick="this.src='captcha.php?'+Math.random()">
          </div>
                    <input type="submit" name="" value="提交" class="f_r btn_style_2">
          </td>
        </tr>
      </tbody></table>
      </form>
        </div>
      </div>
          
</div>
</div>
<div class="blank"></div>
</div>
             
             </div>
             </div>
        </div>
    </div>
    
   
    <div class="blank"></div>
<!-- 包含尾部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/footer.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>