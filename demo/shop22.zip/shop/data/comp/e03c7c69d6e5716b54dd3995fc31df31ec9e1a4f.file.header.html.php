<?php /* Smarty version Smarty-3.1.13, created on 2014-10-24 17:34:49
         compiled from "view\front\header.html" */ ?>
<?php /*%%SmartyHeaderCode:3072453b185a78d6d31-17445917%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e03c7c69d6e5716b54dd3995fc31df31ec9e1a4f' => 
    array (
      0 => 'view\\front\\header.html',
      1 => 1414143280,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3072453b185a78d6d31-17445917',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b185a7916008_80584044',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b185a7916008_80584044')) {function content_53b185a7916008_80584044($_smarty_tpl) {?><div class="blockfull">
<div class="block" style="position:relative;z-index:999999">
	<div class="page_header clearfix">
    	<div class="block" style="height:85px; ">
    	<div class="logo f_l"><a href="#"><img src="./view/front/images/logo.gif"></a></div>
        <div class="member_login f_l">
            <font id="ECS_MEMBERZONE"><div id="append_parent"></div>
  <?php if ($_SESSION['username']!==null){?>
 欢迎光临布尔！&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $_SESSION['username'];?>

 <a href="exit.php" >注销</a>
 <?php }else{ ?>
 <a href="login.php">登录</a> | <a href="reg.php">注册</a> 
 <?php }?>
  </font>            
            </div>
        <div class="page_top f_r">
        
                     <a href="#">诚聘代理</a>
                         |
                            <a href="#">查看购物车</a>
                         |
                            <a href="#">会员中心</a>
                         |
                            <a href="#">优惠活动</a>
                   	
            <div class="telinfo">
			<div><a href="#">
 <img border="0" src="./view/front/images/pa" alt="布尔QQ客服"></a></div>
 </div>
                                   
        </div>
        </div>
    </div>
    
    <div class="mid_nav clearfix" id="mid_nav">
    	<div class="block">
    	<div class="nav_list f_l">
        	<ul>
                                     <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="index.php" class="curr">首页</a>
                  <div class="sub_nav" style="display: none;"><a href="#" class="level_1">西装</a><a href="#" class="level_2">型男系列</a><a href="#" class="level_2">纯色西装</a><a href="#" class="level_2">条纹西装</a><a href="#" class="level_1">衬衫</a><a href="#" class="level_2">正装衬衫</a><a href="#" class="level_2">休闲衬衫</a></div><iframe scrolling="no" frameborder="0" class="nomask" style="display: none;"></iframe>                   </li>

            	<li><a href="category.php?cat_id=1">男士正装</a></li>
              
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=4">女士正装</a>

                  <!-- <div class="sub_nav"><a href="#" class="level_1">套装</a><a href="#" class="level_2">一扣套装</a><a href="#" class="level_2">二扣套装</a><a href="#" class="level_2">短袖套装</a><a href="#" class="level_1">衬衫</a><a href="#" class="level_2">翻领</a><a href="#" class="level_2">V型翻领</a><a href="#" class="level_2">立领</a><a href="#" class="level_1">其它</a><a href="#" class="level_2">西裤</a><a href="#" class="level_2">正装裙</a></div> -->

                  <iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=7">正装鞋</a>
                  <!-- <div class="sub_nav"><a href="#" class="level_1">男士皮鞋</a><a href="#" class="level_2">系带鞋</a><a href="#" class="level_2">非系带鞋</a><a href="#" class="level_1">女士皮鞋</a></div> -->

                  <iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999; text-decoration:line-through" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);" >
                   <a href="">正装租赁</a>
                                     </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=10">配饰</a>
                  <!-- <div class="sub_nav"><a href="#" class="level_1">领带</a><a href="#" class="level_2">纯色</a><a href="#" class="level_2">条纹</a><a href="#" class="level_2">格纹</a><a href="#" class="level_2">蓝色系</a><a href="#" class="level_2">红色系</a><a href="#" class="level_2">黑灰色</a><a href="#" class="level_1">皮带</a></div> -->

                  <iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999;text-decoration:line-through" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="#">实体店面</a>
                                     </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="#" style="text-decoration:line-through">断码特惠</a>
                                     </li>
                                  
                 
                 
                 
                 
                 
            </ul>
        </div>
      <script type="text/javascript">
      //初始化主菜单
		function sw_nav(obj,tag)
		{
			var subdivs = obj.getElementsByTagName("DIV");
			var ifs = obj.getElementsByTagName("IFRAME");
			
			if(subdivs.length>0)
			{
				if(tag==1)
				{
					subdivs[0].style.display = "block";
					ifs[0].style.display = "block";
				}
				else
				{
					subdivs[0].style.display = "none";	
					ifs[0].style.display = "none";
				}
				
			}
		}
      </script>
        </div>
    </div>
</div>
<div class="block">
<div class="f_l" style="width:822px; overflow:hidden">
<div class="hot_cate clearfix">
<div class="f_l"><span class="f_gray_white">热门分类：</span>&nbsp;&nbsp;
&nbsp;<a href="#">西装</a>&nbsp;&nbsp;<a href="#">型男系列</a>&nbsp;&nbsp;<a href="#">衬衫</a>&nbsp;&nbsp;<a href="#">休闲衬衫</a>&nbsp;&nbsp;<a href="#">领带</a>&nbsp;
                     
  <span><b>特别关注:</b> <a href="#" target="_blank">清华店</a> 
<a href="#" target="_blank">五道口店</a> 
<a href="#" target="_blank">人大店</a> 
<a href="#" target="_blank">北邮店</a> 
<a href="#" target="_blank">北航店</a>   
<a href="#" target="_blank">农大店</a> 
<a href="#" target="_blank">西安店</a>
<a href="#" target="_blank">南京店</a>
<a href="#" target="_blank">更多…</a></span>
                     
                     
</div>
</div>
<div class="block clearfix brand_list">
  <div class="search_box f_l">
         <script type="text/javascript">
		
		<!--
		function checkSearchForm()
		{
			if(document.getElementById('keyword').value)
			{
				return true;
			}
			else
			{
				alert("请输入搜索关键词！");
				return false;
			}
		}
		-->
		
		</script>
        <form id="searchForm" name="searchForm" method="get" action="http://www.zhongyis.com/search.php" onsubmit="return checkSearchForm()">
        <select name="category" id="category" class="txt_style_1" style="vertical-align:middle">
      <option value="0">所有分类</option>
          <option value="103">待加分类2</option><option value="148">配饰</option><option value="36">&nbsp;&nbsp;&nbsp;&nbsp;领带</option><option value="147">&nbsp;&nbsp;&nbsp;&nbsp;皮带</option><option value="42">女士正装</option><option value="135">&nbsp;&nbsp;&nbsp;&nbsp;衬衫</option><option value="136">&nbsp;&nbsp;&nbsp;&nbsp;其它</option><option value="134">&nbsp;&nbsp;&nbsp;&nbsp;套装</option><option value="149">断码特惠</option><option value="66">正装租赁</option><option value="17">男士正装</option><option value="18">&nbsp;&nbsp;&nbsp;&nbsp;西装</option><option value="25">&nbsp;&nbsp;&nbsp;&nbsp;衬衫</option><option value="83">正装鞋</option><option value="84">&nbsp;&nbsp;&nbsp;&nbsp;男士皮鞋</option><option value="89">&nbsp;&nbsp;&nbsp;&nbsp;女士皮鞋</option><option value="154">商务大衣</option><option value="128">其它</option>        </select>
        	<input type="text" name="keywords" id="keyword" value="" class="txt_style_search" style="vertical-align:middle; width:120px;"> <input type="submit" class="btn_style_3" value="搜索" style="vertical-align:middle"> &nbsp;
            
            
      
            </form>
        </div>
 <div class="hot_keyword f_l" style=" padding-top:0px; padding-right:5px; overflow:hidden">热门关键字：
	
      <a href="#">正装</a>
      <a href="#">ZYS650</a>
      <a href="#">套裙</a>
      <a href="#">套裤</a>
      <a href="#">158-5</a>
      <a href="#">衬衫</a>
      <a href="#">纯白</a>
      <a href="#">V领</a>
      <a href="#">皮鞋</a>
      <a href="#">正装鞋</a>
      <a href="#">领带</a>
      <a href="#">条纹</a>
    </div>
  
</div>
</div>
<div class="cart_tip f_r" style="position:relative">
<img src="./view/front/images/car.gif">
<a href="#" title="查看购物车">购物车中有 <b>1</b> 件商品 合计 <b>￥799.00元</b></a>
<a href="#" style="position:absolute; top:30px; right:0px;"><img src="./view/front/images/jiesuan.gif"></a>
</div>
</div>
<div class="blank"></div>
<link href="./view/front/css/greybox.css" rel="stylesheet" type="text/css" media="all">
<link href="./view/front/css/polo.css" rel="stylesheet" type="text/css" media="all">
</div><?php }} ?>