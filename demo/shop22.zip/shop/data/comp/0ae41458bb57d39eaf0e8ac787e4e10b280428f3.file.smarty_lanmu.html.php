<?php /* Smarty version Smarty-3.1.13, created on 2014-06-30 17:27:27
         compiled from "D:\wamp\www\shop\view\front\smarty_lanmu.html" */ ?>
<?php /*%%SmartyHeaderCode:2771153b12d53c929a9-91424127%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0ae41458bb57d39eaf0e8ac787e4e10b280428f3' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\smarty_lanmu.html',
      1 => 1404120434,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2771153b12d53c929a9-91424127',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b12d53ce8455_22451389',
  'variables' => 
  array (
    'categoods' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b12d53ce8455_22451389')) {function content_53b12d53ce8455_22451389($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<div class="blockfull">
<div class="block" style="position:relative;z-index:999999">
	<div class="page_header clearfix">
    	<div class="block" style="height:85px; ">
    	<div class="logo f_l"><a href="#"><img src="./view/front/images/logo.gif"></a></div>
        <div class="member_login f_l">
            <font id="ECS_MEMBERZONE"><div id="append_parent"></div>
 欢迎光临布尔！&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="login.php">登录</a> | <a href="reg.php">注册</a>
 </font>            
            </div>
        <div class="page_top f_r">
        
                     <a href="#">诚聘代理</a>
                         |
                            <a href="#">查看购物车</a>
                         |
                            <a href="#">会员中心</a>
                         |
                            <a href="#">优惠活动</a>
                   	
            <div class="telinfo">
			<div><a href="#">
 <img border="0" src="./view/front/images/pa" alt="布尔QQ客服"></a></div>
 </div>
            
            
            
        </div>
        </div>
    </div>
    
    <div class="mid_nav clearfix" id="mid_nav">
    	<div class="block">
    	<div class="nav_list f_l">
        	<ul>
                                     <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="index.php" class="curr">首页</a>
                  <div class="sub_nav" style="display: none;"><a href="#" class="level_1">西装</a><a href="#" class="level_2">型男系列</a><a href="#" class="level_2">纯色西装</a><a href="#" class="level_2">条纹西装</a><a href="#" class="level_1">衬衫</a><a href="#" class="level_2">正装衬衫</a><a href="#" class="level_2">休闲衬衫</a></div><iframe scrolling="no" frameborder="0" class="nomask" style="display: none;"></iframe>                   </li>

            	<li><a href="category.php?cat_id=1">男士正装</a></li>
              
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=4">女士正装</a>
                  <div class="sub_nav"><a href="#" class="level_1">套装</a><a href="#" class="level_2">一扣套装</a><a href="#" class="level_2">二扣套装</a><a href="#" class="level_2">短袖套装</a><a href="#" class="level_1">衬衫</a><a href="#" class="level_2">翻领</a><a href="#" class="level_2">V型翻领</a><a href="#" class="level_2">立领</a><a href="#" class="level_1">其它</a><a href="#" class="level_2">西裤</a><a href="#" class="level_2">正装裙</a></div><iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=7">正装鞋</a>
                  <div class="sub_nav"><a href="#" class="level_1">男士皮鞋</a><a href="#" class="level_2">系带鞋</a><a href="#" class="level_2">非系带鞋</a><a href="#" class="level_1">女士皮鞋</a></div><iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="">正装租赁</a>
                                     </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="category.php?cat_id=10">配饰</a>
                  <div class="sub_nav"><a href="#" class="level_1">领带</a><a href="#" class="level_2">纯色</a><a href="#" class="level_2">条纹</a><a href="#" class="level_2">格纹</a><a href="#" class="level_2">蓝色系</a><a href="#" class="level_2">红色系</a><a href="#" class="level_2">黑灰色</a><a href="#" class="level_1">皮带</a></div><iframe scrolling="no" frameborder="0" class="nomask"></iframe>                   </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="#">实体店面</a>
                                     </li>
                                    <li style="position:relative; z-index:999999" onmouseover="sw_nav(this,1);" onmouseout="sw_nav(this,0);">
                   <a href="#">断码特惠</a>
                                     </li>
                                  
                 
                 
                 
                 
                 
            </ul>
        </div>
      <script type="text/javascript">
      //初始化主菜单
		function sw_nav(obj,tag)
		{
			var subdivs = obj.getElementsByTagName("DIV");
			var ifs = obj.getElementsByTagName("IFRAME");
			
			if(subdivs.length&amp;gt;0)
			{
				if(tag==1)
				{
					subdivs[0].style.display = "block";
					ifs[0].style.display = "block";
				}
				else
				{
					subdivs[0].style.display = "none";	
					ifs[0].style.display = "none";
				}
				
			}
		}
      </script>
        </div>
    </div>
</div>
<div class="block">
<div class="f_l" style="width:822px; overflow:hidden">
<div class="hot_cate clearfix">
<div class="f_l"><span class="f_gray_white">热门分类：</span>&nbsp;&nbsp;
&nbsp;<a href="#">西装</a>&nbsp;&nbsp;<a href="#">型男系列</a>&nbsp;&nbsp;<a href="#">衬衫</a>&nbsp;&nbsp;<a href="#">休闲衬衫</a>&nbsp;&nbsp;<a href="#">领带</a>&nbsp;
                     
  <span><b>特别关注:</b> <a href="#" target="_blank">清华店</a> 
<a href="#" target="_blank">五道口店</a> 
<a href="#" target="_blank">人大店</a> 
<a href="#" target="_blank">北邮店</a> 
<a href="#" target="_blank">北航店</a>   
<a href="#" target="_blank">农大店</a> 
<a href="#" target="_blank">西安店</a>
<a href="#" target="_blank">南京店</a>
<a href="#" target="_blank">更多…</a></span>
                     
                     
</div>
</div>
<div class="block clearfix brand_list">
  <div class="search_box f_l">
         <script type="text/javascript">
		
		&amp;lt;!--
		function checkSearchForm()
		{
			if(document.getElementById('keyword').value)
			{
				return true;
			}
			else
			{
				alert("请输入搜索关键词！");
				return false;
			}
		}
		--&amp;gt;
		
		</script>
        <form id="searchForm" name="searchForm" method="get" action="http://www.zhongyis.com/search.php" onsubmit="return checkSearchForm()">
        <select name="category" id="category" class="txt_style_1" style="vertical-align:middle">
      <option value="0">所有分类</option>
          <option value="103">待加分类2</option><option value="148">配饰</option><option value="36">&nbsp;&nbsp;&nbsp;&nbsp;领带</option><option value="147">&nbsp;&nbsp;&nbsp;&nbsp;皮带</option><option value="42">女士正装</option><option value="135">&nbsp;&nbsp;&nbsp;&nbsp;衬衫</option><option value="136">&nbsp;&nbsp;&nbsp;&nbsp;其它</option><option value="134">&nbsp;&nbsp;&nbsp;&nbsp;套装</option><option value="149">断码特惠</option><option value="66">正装租赁</option><option value="17">男士正装</option><option value="18">&nbsp;&nbsp;&nbsp;&nbsp;西装</option><option value="25">&nbsp;&nbsp;&nbsp;&nbsp;衬衫</option><option value="83">正装鞋</option><option value="84">&nbsp;&nbsp;&nbsp;&nbsp;男士皮鞋</option><option value="89">&nbsp;&nbsp;&nbsp;&nbsp;女士皮鞋</option><option value="154">商务大衣</option><option value="128">其它</option>        </select>
        	<input type="text" name="keywords" id="keyword" value="" class="txt_style_search" style="vertical-align:middle; width:120px;"> <input type="submit" class="btn_style_3" value="搜索" style="vertical-align:middle"> &nbsp;
            
            
      
            </form>
        </div>
 <div class="hot_keyword f_l" style=" padding-top:0px; padding-right:5px; overflow:hidden">热门关键字：
	
      <a href="#">正装</a>
      <a href="#">ZYS650</a>
      <a href="#">套裙</a>
      <a href="#">套裤</a>
      <a href="#">158-5</a>
      <a href="#">衬衫</a>
      <a href="#">纯白</a>
      <a href="#">V领</a>
      <a href="#">皮鞋</a>
      <a href="#">正装鞋</a>
      <a href="#">领带</a>
      <a href="#">条纹</a>
    </div>
  
</div>
</div>
<div class="cart_tip f_r" style="position:relative">
<img src="./view/front/images/car.gif">
<a href="#" title="查看购物车">购物车中有 <b>1</b> 件商品 合计 <b>￥799.00元</b></a>
<a href="#" style="position:absolute; top:30px; right:0px;"><img src="./view/front/images/jiesuan.gif"></a>
</div>
</div>
<div class="blank"></div>
<link href="./view/front/css/greybox.css" rel="stylesheet" type="text/css" media="all">
<link href="./view/front/css/polo.css" rel="stylesheet" type="text/css" media="all">
</div>
</div>
<div id="mainbox" class="block clearfix">
	<div class="layout_2">
    	<div class="layout_left">
       		
<div class="cate_tree">
            	<div class="lib_top">产品分类</div>
                <div class="lib_mid">
                	<ul>
                    	<li class="cate_level_1"><a href="#">男士正装</a></li>
                          <li class="cate_level_2"><a href="#">西装</a></li>
                          <li class="cate_level_2"><a href="#">衬衫</a></li>
                        	       <li class="cate_level_1"><a href="#">女士正装</a></li>
                          <li class="cate_level_2"><a href="#">套装</a></li>
                          <li class="cate_level_2"><a href="#">衬衫</a></li>
                          <li class="cate_level_2"><a href="#">其它</a></li>
                        	       <li class="cate_level_1"><a href="#">正装租赁</a></li>
                        	       <li class="cate_level_1"><a href="#">正装鞋</a></li>
                          <li class="cate_level_2"><a href="#">男士皮鞋</a></li>
                          <li class="cate_level_2"><a href="#">女士皮鞋</a></li>
                        	       <li class="cate_level_1"><a href="#">待加分类2</a></li>
                        	       <li class="cate_level_1"><a href="#">配饰</a></li>
                          <li class="cate_level_2"><a href="#">领带</a></li>
                          <li class="cate_level_2"><a href="#">皮带</a></li>
                        	       <li class="cate_level_1"><a href="#">断码特惠</a></li>
                        	       <li class="cate_level_1"><a href="#">商务大衣</a></li>
                        	       <li class="cate_level_1"><a href="#">其它</a></li>
                               
                    </ul>
                </div>
                <div class="lib_down"></div>
            </div>
            <div class="blank"></div> <div class="shop_left_lib">
<div class="lib_top">销售排行</div>
  <div class="top10List clearfix">
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/images/top_1.gif">
	
      <a title="" href="#">精疏棉涤修身正装衬衫/...</a><br>
      本店售价：<font class="f1">￥150元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/images/top_2.gif">
	
      <a title="" href="#">男士长袖衬衫A52/纯...</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/images/top_3.gif">
	
      <a title="" href="#">白色V领隐斜纹女士修身...</a><br>
      本店售价：<font class="f1">￥69元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/images/top_4.gif">
	
      <a title="" href="#">两扣双开叉黑色细条纹男...</a><br>
      本店售价：<font class="f1">￥699元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_5.gif">
	
      <a title="" href="#">男士正装皮鞋C5161...</a><br>
      本店售价：<font class="f1">￥150元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_6.gif">
	
      <a title="" href="#">彩色细斜纹领带/7.5...</a><br>
      本店售价：<font class="f1">￥69元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_7.gif">
	
      <a title="" href="#">浅蓝细斜纹领带/7.5...</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_8.gif">
	
      <a title="" href="#">3扣纯藏青色男士西服套...</a><br>
      本店售价：<font class="f1">￥399元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_9.gif">
	
      <a title="" href="#">枪驳领后领兜盖捏褶两扣...</a><br>
      本店售价：<font class="f1">￥499元</font><br>
      
    </ul>
    <ul class="clearfix">
	<img class="iteration" src="./view/front/images/top_10.gif">
	
      <a title="" href="#">红黑间隔斜纹领带/7....</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    </div>
</div>
<div class="blank5"></div>
  <div style="display: block;" id="history_div" class="shop_left_lib">
            	<div class="lib_top">浏览历史</div>
                <div id="history_list" class="lib_mid">
                    <ul class="clearfix"><li class="goodsimg"><a target="_blank" href="#"><img class="B_blue" alt="纯羊毛一粒扣枪驳领纯黑西服套装" src="./view/front/images/313_thumb_G_1346420329070.jpg"></a></li><li><a title="纯羊毛一粒扣枪驳领纯黑西服套装" target="_blank" href="#">纯羊毛一粒扣枪驳领纯黑...</a><br>本店售价：<font class="f1">￥1099元</font><br></li></ul><ul class="clearfix"><li class="goodsimg"><a target="_blank" href="#"><img class="B_blue" alt="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" src="./view/front/images/315_thumb_G_1346659439530.jpg"></a></li><li><a title="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" target="_blank" href="#">两扣双开衩平驳头斜兜男...</a><br>本店售价：<font class="f1">￥799元</font><br></li></ul><ul id="clear_history"><a onclick="clear_history()">[清空]</a></ul>             
                </div>
                 <div class="lib_down"></div>
            </div>
            <div class="blank"></div>

  
        	
        </div>
        
        <div class="layout_right">
        <div class="cat_ad">
 </div>
   
         
  
            当前位置: <a href="#">首页</a> <code>&gt;</code> <a href="#">男士正装</a> <div class="blank"></div>
    
           
           
            <div class="shop_right_lib_comm">
            	<div class="innerbox goods_list clearfix">
                  
 <div style="height:20px; padding:0; padding:3px;" class="switch_dispstyle clearfix">
  <form name="listform" class="sort" method="GET">
  <div class="f_l">
  显示方式：
  <a onclick="javascript:display_mode('list')" href="#"><img alt="" src="./view/front/images/display_mode_list.gif"></a>
  <a onclick="javascript:display_mode('grid')" href="#"><img alt="" src="./view/front/images/display_mode_grid_act.gif"></a>
  <a onclick="javascript:display_mode('text')" href="#"><img alt="" src="./view/front/images/display_mode_text.gif"></a>&nbsp;&nbsp;
  
  </div>
  
  <div style=" padding:2px;" class="f_r">
     
  <a href="#"><img alt="按上架时间排序" src="./view/front/images/goods_id_default.gif"></a>
  <a href="#"><img alt="按价格排序" src="./view/front/images/shop_price_default.gif"></a>
  <a href="#"><img alt="按更新时间排序" src="./view/front/images/last_update_DESC.gif"></a>
  <input type="hidden" value="17" name="category">
  <input type="hidden" id="display" value="grid" name="display">
  <input type="hidden" value="0" name="brand">
  <input type="hidden" value="0" name="price_min">
  <input type="hidden" value="0" name="price_max">
  <input type="hidden" value="0" name="filter_attr">
  <input type="hidden" value="1" name="page">
  <input type="hidden" value="last_update" name="sort">
  <input type="hidden" value="DESC" name="order">
    
    </div></form>
</div>
   
    <form onsubmit="return compareGoods(this);" method="post" action="http://www.zhongyis.com/compare.php" name="compareForm">
     
     <div class="grid">
                        <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categoods']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
?>        
                       <div class="goodsItem">
                          <div class="goodsPic">
              
                          <a href="goods.php?goods_id=<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_id'];?>
"><img title="两扣双开衩平驳头斜兜男..." class="zoom" src="./view/front/images/315_G_1346659439860.jpg"><img alt="两扣双开衩平驳头斜兜男..." src="<?php echo $_smarty_tpl->tpl_vars['v']->value['thumb_img'];?>
"></a>
                          </div>
                          <div class="goodsInfo">                             
                              <div class="goodsSn"><a class="f_pname" title="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" href="#"><?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
</a>
                              </div>
                                    <span class="f_gray">市场价：</span>
                                    <font class="f_market">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['market_price'];?>
元</font><br>
                                    本店价：<font class="f_shop">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['shop_price'];?>
元</font><br>
                          </div>
                        </div>  
                        <?php } ?>                      
                    </div>           		
    </form>
    
  
  <div class="blank"></div>
<script language="JavaScript" type="Text/Javascript">
&lt;!--
function selectPage(sel)
{
  sel.form.submit();
}
//--&gt;
</script>
<script type="text/javascript">
window.onload = function()
{
  Compare.init();
  fixpng();
}
var button_compare = '';
var exist = "您已经选择了%s";
var count_limit = "最多只能选择4个商品进行对比";
var goods_type_different = "\"%s\"和已选择商品类型不同无法进行对比";
var compare_no_goods = "您没有选定任何需要比较的商品或者比较的商品数少于 2 个。";
var btn_buy = "购买";
var is_cancel = "取消";
var select_spe = "请选择商品属性";
</script>                    
                </div>            
            </div>
            <div style=" height:25px; background:#e6eaf3;height:25px; overflow:hidden">
<form method="get" action="http://www.zhongyis.com/category.php" name="selectPageForm">
 <div class="pagebar" id="pager">
  <span style="margin-right:10px;" class="f_l f6">总计 <b>6</b>  个记录</span>
                     <!--  <span class="page_now">1</span>
                      <a href="#">[2]</a>
                      <a href="#">[3]</a>
                      <a href="#">[4]</a>
                      <a href="#">[5]</a> -->
                      <span class="page_now">1</span><a href ="/shop/category.php?cat_id=1&page=2" >[2]</a>            
  <!-- <a href="http://www.zhongyis.com/category.php?id=17&amp;price_min=0&amp;price_max=0&amp;page=2&amp;sort=last_update&amp;order=DESC" class="next">下一页</a>  -->   
</div>
</form>
<script language="JavaScript" type="Text/Javascript">
&lt;!--
function selectPage(sel)
{
  sel.form.submit();
}
//--&gt;
</script>
</div>
        </div>
    </div>
<div class="blank"></div>

<!-- 包含尾部-->
       	<div class="help_lib">
            	<div class="help_cats clearfix">
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="新手上路" href="article_cat.php?id=5">新手上路</a></dt>
    <dd><a title="售后流程" href="article.php?id=9">售后流程</a></dd>
    <dd><a title="购物流程" href="article.php?id=10">购物流程</a></dd>
    <dd><a title="订购方式" href="article.php?id=11">订购方式</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="正装常识" href="article_cat.php?id=6">正装常识</a></dt>
    <dd><a title="面试着装十条军规" href="article.php?id=12">面试着装十条军规</a></dd>
    <dd><a title="学生如何挑选西服" href="article.php?id=13">学生如何挑选西服</a></dd>
    <dd><a title="九种打领带的方法" href="article.php?id=14">九种打领带的方法</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="配送与支付" href="article_cat.php?id=7">配送与支付</a></dt>
    <dd><a title="货到付款区域" href="article.php?id=15">货到付款区域</a></dd>
    <dd><a title="配送注意事项" href="article.php?id=16">配送注意事项</a></dd>
    <dd><a title="支付方式说明" href="article.php?id=17">支付方式说明</a></dd>
    <dd><a title="网上支付指南" href="article.php?id=73">网上支付指南</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="会员中心" href="article_cat.php?id=10">会员中心</a></dt>
    <dd><a title="资金管理" href="article.php?id=18">资金管理</a></dd>
    <dd><a title="我的收藏" href="article.php?id=19">我的收藏</a></dd>
    <dd><a title="我的订单" href="article.php?id=20">我的订单</a></dd>
  </dl>
<dl style=" border-right:1px solid #ccc;">
  <dt><a title="服务保证" href="article_cat.php?id=8">服务保证</a></dt>
    <dd><a title="退换货原则" href="article.php?id=21">退换货原则</a></dd>
    <dd><a title="售后服务保证" href="article.php?id=22">售后服务保证</a></dd>
    <dd><a title="产品质量保证" href="article.php?id=23">产品质量保证</a></dd>
    <dd><a title="网购退换货说明" href="article.php?id=66">网购退换货说明</a></dd>
  </dl>
                    
                   <div class="help_tel"> 
                    <div class="t">订购热线（免长途费）</div>
                    <div class="b">400 647 1688</div> 
                    <div class="t">客户服务热线</div>
                    <div class="b">010-82866873 </div>
                   </div>
                    
                </div>
            </div>
 	
</div>
<div class="blank"></div>
<div style="text-align:center"></div>
<div class="page_footer block">
	<div class="foot_nav">
    	<div class="block">
             	<div class="nav_list">
                        <a href="#" style="padding:0 3px 0 5px">隐私保护</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">公司简介</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">联系我们</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">在线客服</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">加盟政策</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">团购优惠</a>  
            
            
                          |
                                    <a href="#" style="padding:0 3px 0 5px">配送方式</a>  
            
            
                         


</div></div></div></div></body></html>

<?php }} ?>