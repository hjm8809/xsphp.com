<?php /* Smarty version Smarty-3.1.13, created on 2014-10-27 15:16:26
         compiled from "D:\wamp\www\shop\view\front\jiesuan.html" */ ?>
<?php /*%%SmartyHeaderCode:49085448b57674cea6-98876928%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3163d0cb54a197b1a8092279c5f5a12c4a79bf9a' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\jiesuan.html',
      1 => 1414144687,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '49085448b57674cea6-98876928',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5448b57679eba0_46002340',
  'variables' => 
  array (
    'items' => 0,
    'v' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5448b57679eba0_46002340')) {function content_5448b57679eba0_46002340($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="Generator" content="ECSHOP v2.7.2">

<meta name="Keywords" content="">
<meta name="Description" content="">

<title>购物流程_布尔正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link rel="shortcut icon" href="http://www.zhongyis.com/favicon.ico">
<link rel="icon" href="http://www.zhongyis.com/animated_favicon.gif" type="image/gif">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">
</head>

<body>

<!-- 包含头部 -->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<div class="blank"></div>

<div class="block">  
当前位置: <a href="#">首页</a> <code>&gt;</code> 购物流程 <div class="blank"></div>

  <div style=" border:1px solid #dcdfe5;padding:1px; padding-bottom:8px;" class="flowBox flowBox1">
   
        <form action="./images/jiesuan.htm" method="post" name="formCart" id="formCart">
           <table width="100%" cellspacing="0" cellpadding="5" border="0" bgcolor="#dddddd" align="center">
            <tbody><tr>
              <th style="background:#7a7f89; color:#333">商品名称</th>
                    <th style="background:#7a7f89; color:#333">属性</th>
                                          <th style="background:#7a7f89; color:#333">市场价</th>
                            <th style="background:#7a7f89; color:#333">本店价</th>
              <th style="background:#7a7f89; color:#333">购买数量</th>
              <th style="background:#7a7f89; color:#333">小计</th>
              <th style="background:#7a7f89; color:#333">操作</th>
            </tr>
            <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['items']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                        <tr>
              <td bgcolor="#ffffff" align="center">
                                                      <a target="_blank" href="#"><img border="0" title="<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['v']->value['thumb_img'];?>
"></a><br>
                    <a class="f6" target="_blank" href="#"><?php echo $_smarty_tpl->tpl_vars['v']->value['goods_name'];?>
</a>
                                                                                    </td>
                            <td bgcolor="#ffffff">尺码:165/84A <br>
</td>
                                          <td bgcolor="#ffffff" align="right">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['market_price'];?>
元</td>
                            <td bgcolor="#ffffff" align="right">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['shop_price'];?>
元</td>
              <td bgcolor="#ffffff" align="right">
                                <input type="text" onkeydown="showdiv(this)" style="text-align:center " class="inputBg" size="4" value="<?php echo $_smarty_tpl->tpl_vars['v']->value['num'];?>
" id="goods_number_449" name="goods_number[449]">
                              </td>
              <td bgcolor="#ffffff" align="right">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['shop_price']*$_smarty_tpl->tpl_vars['v']->value['num'];?>
元</td>
              <td bgcolor="#ffffff" align="center">
                <a class="f6" href="#">删除</a>
                            </td>
            </tr>
            <?php } ?>          
                      </tbody></table>
          <table width="100%" cellspacing="1" cellpadding="5" border="0" bgcolor="#dddddd" align="center">
            <tbody><tr>
              <td bgcolor="#ffffff">
                            购物金额小计 ￥<<?php ?>?php echo $total;?<?php ?>>元，比市场价 ￥<<?php ?>?php echo $market_total;?<?php ?>>元 节省了 ￥<<?php ?>?php echo $discount;?<?php ?>>元 (<<?php ?>?php echo $rate;?<?php ?>>%)              </td>
              <td bgcolor="#ffffff" align="right">
                <!--input type="button" onclick="location.href='flow.php?act=clear'" class="bnt_blue_1" value="清空购物车"-->
                <a href="flow.php?act=clear">清空购物车</a>
                <input type="submit" value="更新购物车" class="bnt_blue_1" name="submit">
              </td>
            </tr>
          </tbody></table>
          <input type="hidden" value="update_cart" name="step">
        </form>
        <table width="100%" cellspacing="0" cellpadding="5" border="0" bgcolor="#dddddd" align="center">
          <tbody><tr>
            <td bgcolor="#ffffff"><a href="#"><img alt="continue" src="./view/front/images/continue.gif"></a></td>
            <td bgcolor="#ffffff" align="right"><a href="flow.php?act=tijiao"><img alt="checkout" src="./view/front/images/checkout.gif"></a></td>
          </tr>
        </tbody></table>
       
    </div>
    <div class="blank5"></div>
  

</div>
<div class="blank"></div>
<div style="text-align:center"></div>

<div class="page_footer block">
	<div class="foot_nav">
    	<div class="block">
             	<div class="nav_list">


                        <a href="http://www.zhongyis.com/article.php?id=2" style="padding:0 3px 0 5px">隐私保护</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=5" style="padding:0 3px 0 5px">公司简介</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=4" style="padding:0 3px 0 5px">联系我们</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=3" style="padding:0 3px 0 5px">在线客服</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=1" style="padding:0 3px 0 5px">加盟政策</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/article.php?id=57" style="padding:0 3px 0 5px">团购优惠</a>  
            
            
                          |
                                    <a href="http://www.zhongyis.com/myship.php" style="padding:0 3px 0 5px">配送方式</a>  
            
            
                         


</div></div></div></div></body>
</html><?php }} ?>