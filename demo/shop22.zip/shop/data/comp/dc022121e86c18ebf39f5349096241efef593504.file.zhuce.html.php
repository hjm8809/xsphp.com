<?php /* Smarty version Smarty-3.1.13, created on 2014-10-15 13:21:31
         compiled from "D:\wamp\www\shop\view\front\zhuce.html" */ ?>
<?php /*%%SmartyHeaderCode:9250543e1f89f208a2-75398680%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc022121e86c18ebf39f5349096241efef593504' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\zhuce.html',
      1 => 1413357692,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9250543e1f89f208a2-75398680',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_543e1f8a008011_47789175',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_543e1f8a008011_47789175')) {function content_543e1f8a008011_47789175($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="ECSHOP v2.7.2" name="Generator">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="" name="Keywords">
<meta content="" name="Description">

<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>

<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">

</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="block block1">
  当前位置: <a href="index.php">首页</a> <code>&gt;</code> 用户中心 <div class="blank"></div>


            <div class="usBox">
  <div class="usBox_2 clearfix">
   <div class="logtitle3"></div>
    <form style="padding-left:200px;" action="regAct.php" method="post" name="formUser">
      <table width="100%" cellspacing="3" cellpadding="5" border="0" align="left">
        <tbody><tr>
          <td width="13%" align="right">用户名</td>
          <td width="87%">
          <input type="text" name="username" size="25" id="username" onblur="is_registered(this.value);" class="inputBg">
            <span id="username_notice" style="color:#FF0000"> *</span>
          </td>
        </tr>
        <tr>
          <td align="right">email</td>
          <td>
          <input type="text" name="email" size="25" id="email" onblur="checkEmail(this.value);" class="inputBg">
            <span id="email_notice" style="color:#FF0000"> *</span>
          </td>
        </tr>
        <tr>
          <td align="right">密码</td>
          <td>
          <input type="password" name="passwd" id="password1" onblur="check_password(this.value);" onkeyup="checkIntensity(this.value)" class="inputBg" style="width:179px;">
            <span style="color:#FF0000" id="password_notice"> *</span>
          </td>
        </tr>
        <tr>
          <td align="right">密码强度</td>
          <td>
            <table width="145" cellspacing="0" cellpadding="1" border="0">
              <tbody><tr align="center">
                <td width="33%" id="pwd_lower">弱</td>
                <td width="33%" id="pwd_middle">中</td>
                <td width="33%" id="pwd_high">强</td>
              </tr>
            </tbody></table>
          </td>
        </tr>
        <tr>
          <td align="right">确认密码</td>
          <td>
          <input type="password" name="repasswd" id="conform_password" class="inputBg" style="width:179px;">
            <span style="color:#FF0000" id="conform_password_notice"> *</span>
          </td>
        </tr>
                      <tr>
          <td>&nbsp;</td>
          <td><label>
            <input type="checkbox" name="agreement" value="1" checked="checked">
            我已看过并接受《<a href="#" style="color:blue" target="_blank">用户协议</a>》</label></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td align="left">
          <input type="submit" value="" class="us_Submit_reg">
          </td>
        </tr>
        <tr>
          <td colspan="2">&nbsp;</td>
        </tr>
                 <tr>
                    <td>&nbsp;</td>
          <td align="left"><a href="#" class="f6">密码问题找回密码</a>   <a href="#" class="f6">注册邮件找回密码</a></td>
                  </tr>

      </tbody></table>
    </form>
  </div>
</div>

 <div class="blank"></div>
 <!-- 包含尾部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/footer.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>