<?php /* Smarty version Smarty-3.1.13, created on 2014-06-30 15:38:43
         compiled from "cateaddfrom.html" */ ?>
<?php /*%%SmartyHeaderCode:1992553b18483631a43-49318208%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5622b1dd22bfb77341b4cb5bace4f0e67b196532' => 
    array (
      0 => 'cateaddfrom.html',
      1 => 1399226602,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1992553b18483631a43-49318208',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_53b18483667a94_50851902',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_53b18483667a94_50851902')) {function content_53b18483667a94_50851902($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<title>新建网页</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="布尔教育 xhtml 12小时入门教程" />
</head>
    <body>
    	<form action="cateadd.php" method="post">
    		栏目名称:<input type="text" name="catename" /><br />
    		栏目简介:<input type="text" name="intro" /><br />
    		<input type="submit" value="提交" />
    	</form>
    </body>
</html><?php }} ?>