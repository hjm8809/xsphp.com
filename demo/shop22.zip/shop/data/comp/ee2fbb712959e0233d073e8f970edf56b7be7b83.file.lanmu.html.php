<?php /* Smarty version Smarty-3.1.13, created on 2014-10-15 12:48:35
         compiled from "D:\wamp\www\shop\view\front\lanmu.html" */ ?>
<?php /*%%SmartyHeaderCode:129185439a7cf622f51-86188344%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ee2fbb712959e0233d073e8f970edf56b7be7b83' => 
    array (
      0 => 'D:\\wamp\\www\\shop\\view\\front\\lanmu.html',
      1 => 1413353824,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '129185439a7cf622f51-86188344',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5439a7cf6930d6_05867319',
  'variables' => 
  array (
    'categoods' => 0,
    'v' => 0,
    'total' => 0,
    'pt' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5439a7cf6930d6_05867319')) {function content_5439a7cf6930d6_05867319($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<title>购物流程_中意斯正装商城-职业装|面试正装|求职正装|男士正装|女士正装|正装衬衫-源于北京,服务全国</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="favicon.ico" rel="shortcut icon">
<link type="image/gif" href="animated_favicon.gif" rel="icon">
<link type="text/css" rel="stylesheet" href="./view/front/css/style.css">
</head>

<body style="cursor: auto;">
<!-- 包含头部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/header.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div>
<div id="mainbox" class="block clearfix">
  <div class="layout_2">
      <div class="layout_left">
          
<div class="cate_tree">
              <div class="lib_top">产品分类</div>
                <div class="lib_mid">
                  <ul>
                      <li class="cate_level_1"><a href="#">男士正装</a></li>
                          <li class="cate_level_2"><a href="#">西装</a></li>
                          <li class="cate_level_2"><a href="#">衬衫</a></li>
                                 <li class="cate_level_1"><a href="#">女士正装</a></li>
                          <li class="cate_level_2"><a href="#">套装</a></li>
                          <li class="cate_level_2"><a href="#">衬衫</a></li>
                          <li class="cate_level_2"><a href="#">其它</a></li>
                                 <li class="cate_level_1"><a href="#">正装租赁</a></li>
                                 <li class="cate_level_1"><a href="#">正装鞋</a></li>
                          <li class="cate_level_2"><a href="#">男士皮鞋</a></li>
                          <li class="cate_level_2"><a href="#">女士皮鞋</a></li>
                                 <li class="cate_level_1"><a href="#">待加分类2</a></li>
                                 <li class="cate_level_1"><a href="#">配饰</a></li>
                          <li class="cate_level_2"><a href="#">领带</a></li>
                          <li class="cate_level_2"><a href="#">皮带</a></li>
                                 <li class="cate_level_1"><a href="#">断码特惠</a></li>
                                 <li class="cate_level_1"><a href="#">商务大衣</a></li>
                                 <li class="cate_level_1"><a href="#">其它</a></li>
                               
                    </ul>
                </div>
                <div class="lib_down"></div>
            </div>
            <div class="blank"></div> <div class="shop_left_lib">
<div class="lib_top">销售排行</div>
  <div class="top10List clearfix">
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_1.gif">
  
      <a title="" href="#">精疏棉涤修身正装衬衫/...</a><br>
      本店售价：<font class="f1">￥150元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_2.gif">
  
      <a title="" href="#">男士长袖衬衫A52/纯...</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_3.gif">
  
      <a title="" href="#">白色V领隐斜纹女士修身...</a><br>
      本店售价：<font class="f1">￥69元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_4.gif">
  
      <a title="" href="#">两扣双开叉黑色细条纹男...</a><br>
      本店售价：<font class="f1">￥699元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_5.gif">
  
      <a title="" href="#">男士正装皮鞋C5161...</a><br>
      本店售价：<font class="f1">￥150元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_6.gif">
  
      <a title="" href="#">彩色细斜纹领带/7.5...</a><br>
      本店售价：<font class="f1">￥69元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_7.gif">
  
      <a title="" href="#">浅蓝细斜纹领带/7.5...</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_8.gif">
  
      <a title="" href="#">3扣纯藏青色男士西服套...</a><br>
      本店售价：<font class="f1">￥399元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_9.gif">
  
      <a title="" href="#">枪驳领后领兜盖捏褶两扣...</a><br>
      本店售价：<font class="f1">￥499元</font><br>
      
    </ul>
    <ul class="clearfix">
  <img class="iteration" src="./view/front/images/top_10.gif">
  
      <a title="" href="#">红黑间隔斜纹领带/7....</a><br>
      本店售价：<font class="f1">￥89元</font><br>
      
    </ul>
    </div>
</div>
<div class="blank5"></div>
  <div style="display: block;" id="history_div" class="shop_left_lib">
              <div class="lib_top">浏览历史</div>
                <div id="history_list" class="lib_mid">
                    <ul class="clearfix"><li class="goodsimg"><a target="_blank" href="#"><img class="B_blue" alt="纯羊毛一粒扣枪驳领纯黑西服套装" src="./view/front/images/313_thumb_G_1346420329070.jpg"></a></li><li><a title="纯羊毛一粒扣枪驳领纯黑西服套装" target="_blank" href="#">纯羊毛一粒扣枪驳领纯黑...</a><br>本店售价：<font class="f1">￥1099元</font><br></li></ul><ul class="clearfix"><li class="goodsimg"><a target="_blank" href="#"><img class="B_blue" alt="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" src="./view/front/images/315_thumb_G_1346659439530.jpg"></a></li><li><a title="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" target="_blank" href="#">两扣双开衩平驳头斜兜男...</a><br>本店售价：<font class="f1">￥799元</font><br></li></ul><ul id="clear_history"><a onclick="clear_history()">[清空]</a></ul>             
                </div>
                 <div class="lib_down"></div>
            </div>
            <div class="blank"></div>

  
          
        </div>
        
        <div class="layout_right">
        <div class="cat_ad">
 </div>
   
         
  
            当前位置: <a href="#">首页</a> <code>&gt;</code> <a href="#">男士正装</a> <div class="blank"></div>
    
           
           
            <div class="shop_right_lib_comm">
              <div class="innerbox goods_list clearfix">
                  
 <div style="height:20px; padding:0; padding:3px;" class="switch_dispstyle clearfix">
  <form name="listform" class="sort" method="GET">
  <div class="f_l">
  显示方式：
  <a onclick="javascript:display_mode('list')" href="#"><img alt="" src="./view/front/images/display_mode_list.gif"></a>
  <a onclick="javascript:display_mode('grid')" href="#"><img alt="" src="./view/front/images/display_mode_grid_act.gif"></a>
  <a onclick="javascript:display_mode('text')" href="#"><img alt="" src="./view/front/images/display_mode_text.gif"></a>&nbsp;&nbsp;
  
  </div>
  
  <div style=" padding:2px;" class="f_r">
     
  <a href="#"><img alt="按上架时间排序" src="./view/front/images/goods_id_default.gif"></a>
  <a href="#"><img alt="按价格排序" src="./view/front/images/shop_price_default.gif"></a>
  <a href="#"><img alt="按更新时间排序" src="./view/front/images/last_update_DESC.gif"></a>
  <input type="hidden" value="17" name="category">
  <input type="hidden" id="display" value="grid" name="display">
  <input type="hidden" value="0" name="brand">
  <input type="hidden" value="0" name="price_min">
  <input type="hidden" value="0" name="price_max">
  <input type="hidden" value="0" name="filter_attr">
  <input type="hidden" value="1" name="page">
  <input type="hidden" value="last_update" name="sort">
  <input type="hidden" value="DESC" name="order">
    
    </div></form>
</div>
    <form onsubmit="return compareGoods(this);" method="post" action="http://www.zhongyis.com/compare.php" name="compareForm">


<!--xxx-->
<div class="grid">
                        <?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['categoods']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
                        <div class="goodsItem">
                          <div class="goodsPic">
              
                          <a href="goods.php?goods_id=<?php echo $_smarty_tpl->tpl_vars['v']->value['goods_id'];?>
"><img title="两扣双开衩平驳头斜兜男..." class="zoom" src="./view/front/images/315_G_1346659439860.jpg"><img alt="两扣双开衩平驳头斜兜男..." src="<?php echo $_smarty_tpl->tpl_vars['v']->value['thumb_img'];?>
"></a>
                          </div>
                          <div class="goodsInfo">                             
                              <div class="goodsSn">
                                <a class="f_pname" title="两扣双开衩平驳头斜兜男士西服套装3312/纯藏青色人字纹/羊毛+涤纶" href="#">                                
                                <?php echo mb_substr($_smarty_tpl->tpl_vars['v']->value['goods_name'],'0','12','utf-8');?>
...
                              </a>
                              </div>
                                    <span class="f_gray">市场价：</span>
                                    <font class="f_market">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['market_price'];?>
元</font><br>
                                    本店价：<font class="f_shop">￥<?php echo $_smarty_tpl->tpl_vars['v']->value['shop_price'];?>
元</font><br>
                          </div>

                        </div>  
<?php } ?> 
<!--xxx-->
</div>
    </form>
    
  
  <div class="blank"></div>
<script language="JavaScript" type="Text/Javascript">
&lt;!--
function selectPage(sel)
{
  sel.form.submit();
}
//--&gt;
</script>
<script type="text/javascript">
window.onload = function()
{
  Compare.init();
  fixpng();
}
var button_compare = '';
var exist = "您已经选择了%s";
var count_limit = "最多只能选择4个商品进行对比";
var goods_type_different = "\"%s\"和已选择商品类型不同无法进行对比";
var compare_no_goods = "您没有选定任何需要比较的商品或者比较的商品数少于 2 个。";
var btn_buy = "购买";
var is_cancel = "取消";
var select_spe = "请选择商品属性";
</script>                    
                </div>            
            </div>
            <div style=" height:25px; background:#e6eaf3;height:25px; overflow:hidden">
<form method="get" action="http://www.zhongyis.com/category.php" name="selectPageForm">
 <div class="pagebar" id="pager">
  <span style="margin-right:10px;" class="f_l f6">总计 <b><?php echo $_smarty_tpl->tpl_vars['total']->value;?>
</b>  个记录</span>
                     <!--  <span class="page_now">1</span>
                      <a href="#">[2]</a>
                      <a href="#">[3]</a>
                      <a href="#">[4]</a>
                      <a href="#">[5]</a> -->
                      <?php echo $_smarty_tpl->tpl_vars['pt']->value;?>

            
  <!-- <a href="http://www.zhongyis.com/category.php?id=17&amp;price_min=0&amp;price_max=0&amp;page=2&amp;sort=last_update&amp;order=DESC" class="next">下一页</a>  -->   
</div>
</form>
<script language="JavaScript" type="Text/Javascript">
&lt;!--
function selectPage(sel)
{
  sel.form.submit();
}
//--&gt;
</script>
</div>
        </div>
    </div>
<div class="blank"></div>

<!-- 包含尾部-->
<?php echo $_smarty_tpl->getSubTemplate ('view/front/footer.html', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>