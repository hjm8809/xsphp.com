goods_name,
goods_sn,
market_price,
shop_price,
goods_desc,
goods_weight,
is_best,
is_on_sale,
goods_brief,
goods_id,
is_new,
is_hot,
ori_img


      cat_id:0 ?	OK

    brand_id:0
goods_number:1	X	OK
 click_count:0
   thumb_img:''	X	上传类问题
   goods_img:''	X	上传类问题
   is_delete:0
    add_time:0
 last_update:0

 产品内容页 产品描述未做好.
 产分类页,排序需要使用倒序