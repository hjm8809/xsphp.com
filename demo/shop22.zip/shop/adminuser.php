<?php 
/****
所有由用户直接访问到的这些页面,c
都必须加载init.php
adminuser.php 测试model类
****/

//加载文件 init.php  conf.class.php
require('./include/init.php');

$test = new TestModel();
$data = array('t1'=>'admin_t1','t2'=>'admin_t2');
$test->reg($data);




?> 