<?php 
/****
所有由用户直接访问到的这些页面,
都必须加载init.php
fontuser.php 测试model
****/

//加载文件 init.php  conf.class.php
require('./include/init.php');


$test = new TestModel();
$data = array('t1'=>'fontuser_Model1','t2'=>'fontuser_2');
$x=$test->reg($data)


?> 