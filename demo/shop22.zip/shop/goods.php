<?php 
/****

****/

define('ACC',true);
include('include/init.php');

$goods_id = isset($_GET['goods_id'])?$_GET['goods_id']+0:0;
// $goods_id = 10;
//先查询这个商品信息
$goods = new GoodsModel();
$g = $goods->find($goods_id);
// print_r($g);exit;

if(empty($g)){
	header('location:index.php');
	exit;
}

$cat = new CateModel();
$tree = $cat->getTree($g['cat_id']);//顶端分类与终端分类分开考虑.终端分类中,cat_id=parent_id;
// print_r($tree);exit;
$smarty->assign('tree',$tree);
$smarty->assign('g',$g);
$smarty->display(ROOT.'view/front/shangpin.html');
?>