<?php 
/****
file logout
作用 销毁session
****/

define('ACC',true);
include('./include/init.php');

session_destroy();
$msg = '成功注销';
include(ROOT.'/view/front/msg.html');


?>