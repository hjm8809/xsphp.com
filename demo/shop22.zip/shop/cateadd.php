<?php 
/****
cateadd.php
接收处理cateaddfrom.html传过来的数据
****/
/*
老式做法:
1.接收数据
2.检验数据
3.拼凑sql,并执行
判断返回值

现在的MVC开发方式
接收数据
检验数据
把数据交给model去写入数据库
判断model的返回值
*/

require('./include/init.php');
//接收
$data['catename'] = $_POST['catename'];
$data['intro'] = $_POST['intro'];

//关于名称的检测,如有无重复,此处不演示

//调用model来执行

$cateModel = new CateModel();
if($cateModel->add($data)){
	$rs = true;
}else{
	$rs = false;
}

//把结果到展示到view里
//此处直接打印

$rs?print'成功':print'失败';
?>