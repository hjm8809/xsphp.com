<?php 
/****
file login.php
作用 用户登陆界面
****/
define('ACC',true);
require('./include/init.php');		
// print_r($_POST);

if(isset($_POST['act'])){
//通过if,说明是通过点击登陆按钮过来的
//收用记名/密码/验证...
	$u = $_POST['username'];
	$p = $_POST['passwd'];
//合法性检验,暂略

	$user = new UserModel();
	// 核对用户用/密码
	$row = $user->checkUser($u,$p);
		// var_dump($row);		
	if(!$row){
		$msg = '用户名或密码不正确';		
	}else{
		$msg = '用户登陆成功';
		$_SESSION = $row;		
		// print_r($row);
		// var_dump($_SESSION);
		//记录上次登陆过的用户名
		if(isset($_POST['remember'])&&($_POST['remember']==1)){
		setcookie('username',$_POST['username'],time()+3600*24*7,'/');
	}
	}
	// $smarty->display(ROOT.'view/front/msg.html');
	// include(ROOT.'view/front/msg.html');
	//赋值
	$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'view/front/msg.html');
	exit;
}else{
	//准备登陆
	$smarty->display(ROOT.'view/front/denglu.html');

}
?>