<?php 
/****
测试 UpTool.class.php的功能

****/

define('ACC',true);
require('./include/init.php');

$uptool = new UpTool();
$uptool->setSize(2);//设置允许上传文件大小为2M
$uptool->setExt('jpg,rar');//设置允许上传文件类型为jpg,rar
if($res=$uptool->up('avatar')){
	echo 'OK';
	echo $res;
}else{
	echo $uptool->getErr();
}


?>