<?php 
/****
file reg.php
功能 展示注册表单
****/

define('ACC',true);
include('./include/init.php');

$smarty->display(ROOT.'view/front/zhuce.html');

?>