<?php 
/****
file regAct.php
作用 完成注册
****/

define('ACC',true);
include('./include/init.php');
// print_r($_POST);exit;
$user = new UserModel();
//检验用户名是否已经存在
if($user->checkUser($_POST['username'])){	
	$msg = '用户名已存在';
	$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'/view/front/msg.html');
	exit ;
}
/*
调用自动检验功能
检测用户名4-16字符
email检测
passwd不能为空
*/




// 自动过滤
$data = $user->_facade($_POST);
// print_r($data);

//自动填充
// $data = $user->_autofill($_POST);

//自动验证
// var_dump($user->_validata($data));exit;
if(!$user->_validata($data)){
	$msg = $user->getErr();
	var_dump($msg);
	include(ROOT.'view/front/msg.html');
	exit;
}
if($user->reg($data)){
	$msg = '用户注册成功';
}else{
	$msg = '用户注册失败';
}
$smarty->assign('msg',$msg);
$smarty->display(ROOT.'view/front/msg.html');

?>