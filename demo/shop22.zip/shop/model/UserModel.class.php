<?php 
/****
file UserModel.class.php
作用 处理用户注册数据
****/

defined('ACC')||exit('ACC Denined');

class UserModel extends Model{
	protected $table = 'user';
	protected $major_key = 'user_id';
	protected $fields = array('user_id','username','email','passwd','regtime','lastlogin');
	
	protected $_valid = array(
		array('username',1,'用户名长度须在4-16位范围内','length','4,16'),
		array('email',1,'不是email格式','email'),
		array('passwd',1,'密码长度须在4-16位范围内','length','4,16')
		);


	public function reg($data){
		if($data['passwd']){
			$data['passwd'] = $this->encPasswd($data['passwd']);
			return $this->add($data);
		}
	}

	protected function encPasswd($p){
		return md5($p);
	}
	/*
	根据用户名查询用户信息
	*/
	public function checkUser($username,$passwd = ''){	
		//$passwd=''时,可在注册时检验账号是否可用	
		if($passwd == ''){
		$sql = "select * from $this->table where username = '".$username."' ";
		return $this->db->getRow($sql);
		 }else {
		 	//登陆时检验md5
		 	$passwd = md5($passwd);
		 	$sql = "select * from $this->table where username = '$username' and passwd = '$passwd'" ;
		 	return $this->db->getRow($sql);//返回数组或者false;
		 }

	}

}
?>