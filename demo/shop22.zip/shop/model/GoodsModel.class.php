<?php 

class GoodsModel extends Model{
	protected $table = 'goods';
	protected $major_key = 'goods_id';
	protected $fields = array(
'goods_id','goods_sn','goods_name','cat_id','shop_price','market_price','goods_weight','goods_number','goods_brief','goods_desc','is_on_sale','is_best','is_new','is_hot','is_delete'
							);
	protected $_auto = array(
							 array('is_on_sale','value',0),
							 array('is_new','value',0),
							 array('is_hot','value',0),
							);
	/*
	 方法 trash
	 作用 逻辑删除商品(回收站) //is_delete = 1;
	 param $kid
	 return bool //是否删除成功
	*/
	 public function trash($kid){
	 	$data = array('is_delete'=>1);
	 	return $this->update($data,$kid);
	 	// return $this->db->effected_rows();
	 }

	 /*
	 方法 restore
	 作用 从回收站恢復商品 //is_delete = 0;
	 param $kid
	 return bool //是否恢复成功
	*/
	 public function restore($kid){
	 	$data = array('is_delete'=>0);
	 	return $this->update($data,$kid);
	 	// return $this->db->effected_rows();
	 }

	 /*
	  方法 getgoods
	  作用 获取所有在售商品
	  param sql语句
	  return array()
	  备注 where is_delete=0	
	 */
	public function getgoods(){
		$sql = "select * from $this->table where is_delete = 0";
		return $this->db->getAll($sql);

	}

	 /*
	  方法 gettrash
	  作用 获取回收站中的所有商品
	  param sql语句
	  return array()
	  备注 where is_delete=0	
	 */
	public function gettrash(){
		$sql = "select * from $this->table where is_delete = 1";
		return $this->db->getAll($sql);

	}
	/*
		创建商品的货号
	*/
	public function createSn(){
		$sn = 'BL'.date('Ymd').mt_rand(10000,99999);
		$sql = "select * from $this->table where goods_sn = $sn";
		return $this->db->getRow($sql)?$this->createSn():$sn;
	}

	/*
	 	取出指定条数的新品
	*/

	public function getNew($n = 5){
		$sql = "select goods_id,goods_name,market_price,shop_price,thumb_img from $this->table order by add_time limit ".$n.";";
		return $this->db->getAll($sql);
	}

	/*
		获取购物车中商品的详细信息
		param array$items 购物车中的商品数组
		return 商品数组的详细信息
	*/
	public function getCartGoods($items){
		foreach($items as $k=>$v){
		$sql = 'select goods_id,goods_name,thumb_img,shop_price,market_price from '.$this->table.' where goods_id ='.$k;
			$row = $this->db->getRow($sql);
			$row['num'] = $v['num'];			
			$items2[$k] = $row;
		}
			// print_r($row);
			// print_r($items2);exit;
		return $items2;
	}
	/*
	fun getCateGoods
	作用 获取某一分类下的所有商品[需要CateModel中getCateTree方法获取该分类的子孙分类的主键,并使用,合并成字符串]
	param array $data //待选商品[需要调用Model中的select方法]
		  string $cat_str //某分类的子孙树组合成的字符串
	return array $arr //返回商品信息数组
	*/
	function getCateGoods($data,$cat_str){
		$sql = 'select * from '.$this->table.' where cat_id in('.$cat_str.')';
		return $this->db->getAll($sql);
	}

	/*
	fun getpagegoods
	作用 取出栏目=$cat_id下的所有商品(含分页功能)
	param $cat_id 
		  $offset
		  $perpage
	*/
	function getPageGoods($cat_id,$offset,$perpage){

		$cate = new CateModel();
		$catelist = $cate->select();
		$tree = $cate->getCatTree($catelist,$cat_id);
		$in = array($cat_id);
		foreach ($tree as $v){
			$in[] = $v['cat_id'];
			$in = array_unique($in);
		}
		$in = implode(',',$in);
// ===调试===开始===
/*
		print_r($tree);
		echo '$cat_id = ',$cat_id;
		echo '$offset = ',$offset;
		echo '<br />';
		echo '$in = ',$in;		
*/
// ===调试===结束===
		// print_r($in); 
		$sql = 'select * from '.$this->table.' where cat_id in ('.$in.') limit '.$offset.','.$perpage;
		// $sql = select * from $this->table where cat_id = $cat_id limit $offset,$perpage;
		return $this->db->getAll($sql);
	}
}
?>