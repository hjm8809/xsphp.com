<?php 
/****
file UserModel.class.php
作用 处理用户注册数据
****/

defined('ACC')||exit('ACC Denined');

class OIModel extends Model{
	protected $table = 'orderinfo';
	protected $major_key = 'order_id';
	protected $fields = array(
		'order_id','order_sn','user_id','username','zone','address','zipcode','email','tel','mobile','building','best_time','add_time','order_amount','pay','reciver'
    		);

	protected $_valid =array(
			array('reciver',1,'收货人不能为空'),
			array('email',1,'email异常,请重新输入'),
			array('payment',1,'必须选择支付方式','in','4,5')//表示支付货到付款/在线支付
		);

	protected $_auto = array(
		 // array('order_sn','value','defalut'),
		 // array('user_id','value',0),
		 // array('username','value','default'),
		 array('add_time','function','time'),
		 // array('order_amount','value',0)
		);
	public function orderSn(){
		$sn = 'OI'.date('Ymd').mt_rand(10000,99999);
		$sql = 'select count(*) from '.$this->table."where order_sn='$sn'";
		return $this->db->query($sql)?$this->orderSn():$sn;
	}

	public function invoke($order_id){
		$this->delete($order_id);//先删订单
		//再删订单对应商品
		$sql = delete from ordergoods where order_id = $order_id;
		return $this->db->query($sql);
	}
}


?>