<?php 
defined('ACC')||exit('ACC Denied');
/****
model.class.php TestModel的父类
****/

class Model{
	protected $table = 'Model';//是model所控制的表
	protected $db = NULL;//是引入的mysql对象
	protected $major_key = NULL;
	protected $kid = NULL;
	protected $fields = NULL;
	protected $error = array();
	public function __construct(){
		$this->db = mysql::getIns();
	}

	// 在model中写CURD方法
	//insert into $table ($columns) values($values);
	//delete from $table where f$condiction;
	//update from $table set $column $data where $condiction;
	//select * from $table;

	/*
	function add
	parm 	$table,$data,
	retrun resource/bool
	*/
	public function add($data){
		return $this->db->autoExecute($data,$this->table,'insert');		
	}
	/*
	function delete
	parm $major_key/$kid/$table
	retrun 受影响行数/bool
	*/
	public function delete($kid){
		$sql = "delete from $this->table where $this->major_key = $kid";
		if($this->db->query($sql)){
		return $this->db->affected_rows();
	}else{
		return flase;
	}		
	}

	/*
	function select
	parm $table
	retrun resource/bool
	*/
	public function select(){
		$sql = "select * from $this->table";
		return $this->db->getAll($sql);

	}

	/*
	function find
	parm 
	retrun
	*/
	public function find($kid){
		$sql = "select * from $this->table where $this->major_key = $kid";
		return $this->db->getRow($sql);
		
	}

	/*
	function update
	parm 
	retrun
	*/
	public function update($data,$kid){
		$where = "where $this->major_key = $kid";
		$rs = $this->db->autoExecute($data,$this->table,'update',$where);
		if($rs){
		return $this->db->affected_rows();
	}else{
		return false;
	}
	}

	/*
        格式 $this->_valid = array(
                    array('验证的字段名',0/1/2(验证场景),'报错提示','require/in(某几种情况)/between(范围)/length(某个范围)','参数')
        );

        array('goods_name',1,'必须有商品名','requird'),
        array('cat_id',1,'栏目id必须是整型值','number'),
        array('is_new',0,'iN_new只能是0或1','in','0,1')
        array('goods_breif',2,'商品简介就在10到100字符','length','10,100')

    */
    public function _validata($data) {
        //_valid未指定,则返回TRUE
        if(empty($this->_valid)) {
            return true;
        }

        $this->error = array();

        foreach($this->_valid as $k=>$v) {

        	if(!array_key_exists(3,$v)){
        		$v[3] = NULL;
        	}
        	if(!array_key_exists(4,$v)){
        		$v[4] = NULL;
        	}

            // 0/1/2三种场景
            switch($v[1]) {

                case 1:
                    //必须验证,如果字段未设置,则提示错误
                    if(empty($data[$v[0]])) {
                        $this->error[] = $v[0].'不能为空';
                        return false;
                    }
                     
                    if(!$this->check($data[$v[0]],$v[3],$v[4])) {
                        $this->error[] = $v[2];
                        return false;
                    }
                    return true;
                case 0:
                    if(isset($data[$v[0]])) {
                        if(!$this->check($data[$v[0]],$v[3],$v[4])) {
                            $this->error[] = $v[2];
                            return false;
                        }
                    }  
                    return true;                  
                case 2:
                    if(!empty($data[$v[0]])) {
                        if(!$this->check($data[$v[0]],$v[3],$v[4])) {
                            $this->error[] = $v[2];
                            return false;
                        }
                    }
                    return true;
                default:
                return true;
            }
        }
    }

    public function getErr(){
    	return $this->error;
    }
    //具体验证方法 check
    /*param mix $value 对应字段的值 /username/passwd
	  		string $rule 规则类型 0/1/2
	  		string $parm  条件参数
	  return bool
	*/
    protected function check($value,$rule='',$parm='') {
        switch($rule) {            
            case 'number'://必须为数字
                return is_numeric($value);//是数字,返回真

            case 'in'://在某值内
                $tmp = explode(',',$parm);//客户端给(5,15)格式,然后拆分
                return in_array($value,$tmp);//在=>true
            case 'between'://在某范围内
                list($min,$max) = explode(',',$parm);
                return $value >= $min && $value <= $max;
            case 'length'://在某长度内
                list($min,$max) = explode(',',$parm);
                return strlen($value) >= $min && strlen($value) <= $max;
            case 'email':
                // 判断$value是否是email,可以用正则表达式,但现在没学.
                // 因此,此处用系统函数来判断
            return filter_var($value,FILTER_VALIDATE_EMAIL);
        }
    }

    	/*
	fun _facade
	作用   对传POST过来的数组进行过滤,
		过滤规则为:POST数级的键与在fields数组[一般使用数据库的字段]范围内刚留下
	param array $array //POST过来的数组
	return array $data //过滤后的数组
    	*/
	public function _facade($array=array()){
		$data = array();
		foreach($array as $k=>$v){
			if(in_array($k,$this->fields)){
				$data[$k]=$v;
			}
		}return $data;
	}

	/*
	函数:_autoFill()
	作用:自动填充缺失数据字段
	param:$data #被过滤的一维数组#
		  $_auto #说明需要填充字段的二维数组#
	return $data #过滤后的一维数组#
	*/
	public function _autoFill($data){
		foreach($this->_auto as $v){  
			if(!array_key_exists($v[0],$data)){
				switch($v[1]){
					case 'value':
					$data[$v[0]] = $v[2];
					break;
					case 'function':
					$data[$v[0]] = call_user_func($v[2]);
					break;
				}
			}
		}return $data;
	}

	public function insert_id(){
		return $this->db->insert_id();
	}
}



?>