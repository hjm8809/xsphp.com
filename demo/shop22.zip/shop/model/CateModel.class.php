<?php 
/****
file CateAddModel.class.php
负责处理栏目增加的数据入库工作
****/

class CateModel extends Model{
	protected $table = 'category';
	protected $major_key='cat_id';
	protected $fields =array();
	protected $_valid =array();


	
	/*
		fun getCatTree()
		作用:遍历$data,找出主键 的所有子孙目录返回$tree数组//$data 是category表的所有数据
		pram:int $cat_id
		return $cat_id栏目子孙树
	*/
	public function getCatTree($data,$key_id=0,$lev=1){
		static $tree=array();
		foreach($data as $v){
			if ($v['parent_id']==$key_id){
				$v['lev']=$lev;
				$tree[]=$v;
				$tree += array_merge($this->getCatTree($data,$v['cat_id'],$lev+1));
			}
		}return $tree;

	}

	/*
	1.新增功能:若栏目F有子栏目Z,则不允许删除
	思路:
	遍历数组,查询是否存在Z栏目的parent_id = F栏目的cat_id.
	若有,禁止删除,若无,可以删除
	*/
	/*
		fun getSon()
		作用 判断传过来的$cat_id对应分类中, 是否还有子分类.有->true,无->false
		parm:int $cat_id
		return bool
	*/

	public function getSon($cat_id){
		$sql = 'select cat_id from '.$this->table.' where parent_id = '.$cat_id;
		$this->db->query($sql);
		return $this->db->affected_rows();
	}

	/*
		fun getTree()
		作用:从具体的商品$cat_id找父类
		parm:int $parent_id //$cat_id对象的parent_id
		return:array() 某分类的子孙类数组
		说明:getTree()方法,是查找以某主键为中心对象 的商品的父类
	*/


		/*
		
		getTree
		$parent_id
		$arr= category array
		

		*/
		public function getTree($parent_id){
			$arr=$this->select();
			$tree2 = array();
			while($parent_id>0){
			foreach($arr as $v){
				if($v['cat_id']==$parent_id){
					$tree2[]=$v;
					$parent_id = $v['parent_id'];
					break;
				}
		}
			}return array_reverse($tree2);
		}

}

?>