<?php 
/****
file UserModel.class.php
作用 处理用户注册数据
****/

defined('ACC')||exit('ACC Denined');

class OGModel extends Model{
	protected $table = 'ordergoods';
	protected $major_key = 'og_id';
	
	//把订单中的商品写入ordergoods表
	public function addOG($data){
		if($this->add($data)){
		$sql = 'update goods set goods_number = goods_number - '.$data['goods_number'].' where goods_id = '.$data['goods_id'];
		return $this->db->query($sql);
		}
	}return false;


}


?>