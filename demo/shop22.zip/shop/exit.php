<?php 
/****
file login.php
作用 用户登陆界面
****/
define('ACC',true);
require('./include/init.php');		

if(isset($_SESSION['username'])){
	session_destroy();
	$msg='注销成功,欢迎再来!';
}else{
	$msg='尚未登陆,请登陆后再试!';
}
	$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'view/front/msg.html');
?>