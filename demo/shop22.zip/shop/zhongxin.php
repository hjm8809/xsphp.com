<?php 
/****
所有由用户直接访问到的这些页面,
都必须加载init.php
****/

//加载文件 init.php

//开启权限控制
define('ACC',true);
//初始化
require('./include/init.php');

//取出5条新品
// $goods = new GoodsModel();
// $newlist = $goods->getNew(5);
// print_r($newlist);exit;


include(ROOT.'view/front/zhongxin.html');

?> 