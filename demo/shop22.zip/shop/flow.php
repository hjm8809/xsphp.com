<?php 
/****
购物车流程页面
商城的核心功能

功能实现原理:
在按下按钮时,向浏览器传送一个参数,C通过GET方法接收,并自动执行对应的方法
具体的方法有:
$act == 'buy'	加入购物车
$act == 'clear' 清空购物车
$act == 'tijiao' 跳转到填写收货人信息页面
$act == 'done' 验证数据,并写入数据库
****/

define('ACC',true);
require('./include/init.php');

//设置一个动作参数,判断用户想干什么,比如是下订单/写地址/提交/清空购物车等
$act = isset($_GET['act'])?$_GET['act']:buy;

$cart  = CartTool::getCart();//获取购物车实例
$goods = new GoodsModel();
if($act == 'buy'){//把商品加到购物车  end==76
	$goods_id = isset($_GET['goods_id'])?$_GET['goods_id']+0:0;
	$num = isset($_GET['num'])?$_GET['num']+0:1;
// echo $num;exit;
	if($goods_id){
	//$goods_id为真,是想把商品放入购物车
		$g = $goods->find($goods_id);
		// print_r($g);
		if(!empty($g)){//有商品
			//需要判断此商品,是否在回收站
			//是否已下架?
			//库存是否足够?
			if($g['is_delete']==1||$g['is_on_sale'] ==0){
				$msg = '商品已下架';
				$smarty->assign('msg',$msg);
				$smarty->display(ROOT.'/view/front/msg.html');
				exit;
			}
		//商品加入购物车
			$cart->addItem($goods_id,$g['goods_name'],$g['shop_price'],$num);
		}
		//判断库存
		$items = $cart->all();
		//如购买量>库存量
		// echo $items[$goods_id]['num'],$g['goods_number'];
		// exit;
		if($items[$goods_id]['num'] > $g['goods_number']){
			$cart->decNum($goods_id,$num);
			$msg = '库存不足,购买失败';
			$smarty->assign('msg',$msg);
				$smarty->display(ROOT.'/view/front/msg.html');

		}
		// print_r($cart);
		}
		$items = $cart->all();
		if(empty($items)){//若购物车为空,跳转到首页.
			header('location:index.php');
			exit;
	}
	// print_r($items);exit;
	$items = $goods->getCartGoods($items);

	$total = $cart->getPrice();
	$market_total = 0.0;
	foreach($items as $v){
		$market_total += $v['market_price']*$v['num'];
	}
	$discount = $market_total-$total;
	$rate = round((1-($discount/$market_total))*100,0);
	// print_r($items);exit;
		$smarty->assign('items',$items);
		$smarty->display(ROOT.'/view/front/jiesuan.html');
}else if($act == 'clear'){
	$cart->clear();
	$msg = '购物车已清空';
	$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'/view/front/msg.html');
}else if($act == 'tijiao'){
	$items = $cart->all();
	$g = new GoodsModel();
	$items = $g->getCartGoods($items);
	$total = $cart->getPrice();
	$market_total = 0.0;
	foreach($items as $v){
		$market_total += $v['market_price']*$v['num'];
	}
	$discount = $market_total-$total;
	$rate = round((1-($discount/$market_total))*100,0);
	// print_r($items);exit;
	$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'/view/front/tijiao.html');
}else if($act == 'done'){
	/*
	订单入库,最重要的一个环节
	从表单读取送货地址,手机等信息
	从购物车读取总价格信息
	写入orderinfo表
	*/
	// print_r($_POST);
	$OI = new OIModel();
	//过滤数据库无用字段
	$data = $OI->_facade($_POST);
	// print_r($data);
	//自动填充数据库需要字段
	$data = $OI->_autoFill($data);

	// 写入总金额
	$data['order_amount'] = $cart->getPrice();
	//写入用户名
	$data['user_id'] = isset($_SESSION['user_id'])?$_SESSION['user_id']:0;
	$data['username'] = isset($_SESSION['username'])?$_SESSION['username']:'匿名';
	//写入订单号
	$data['order_sn'] = $OI->orderSn();
	// print_r($data);exit;
	// 过滤,暂时不写
	/*
	if(!$OI->_validata($data)){
		$msg = implode(',',$OI->getErr());
		include (ROOT.'/view/front/msg.html');
		exit;
	}
	*/
	//写入数据库
	// echo '通过检验';
	// print_r($_SESSION);exit;

	if($OI->add($data)){
		$msg = '订单提交成功,请进入结算页面';
		$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'/view/front/msg.html');
	}else{
		echo '订单提交失败';
	}

	//获取刚刚产生的order_id的值
	$order_id = $OI->insert_id();
	/*

	要把订单的商品写入数据库
	1个订单里面有N个商品,我们可以循环写入ordergoods表

	*/	
	$items = $cart->all();//返回订单中所有商品
	$OG = new OGModel(); 
 $cnt = 0;
	foreach ($items as $k=>$v){//循环商品,逐次写入
 $data_og = array();
 $data_og['order_id'] = $order_id;
 $data_og['order_sn'] =$OI->orderSn();
 $data_og['goods_id'] = $k;
 $data_og['goods_name'] = $v['name'];
 $data_og['goods_nunber'] = $v['num'];
 $data_og['shop_price'] = $v['price'];
 $data_og['subtotal'] = $v['price']*$v['num'];
 if($OG->addOG($data_og)){
 	$cnt +=1; //插入成功,则$cnt+1;
 }
}
	if(count($items)!== $cnt){
	//购物车并未全部录入数据库
	//此情况,撤消此订单
		$OI->invoke($order_id);
		$msg = '下单失败';
		$smarty->assign('msg',$msg);
	$smarty->display(ROOT.'view/front/msg.html');
		exit;
	}
	//下订单成功
	//清空购物车
	$cart->clear();
	include(ROOT.'view/front/order.html');
}




?>