<?php 
/****
所有由用户直接访问到的这些页面,
都必须加载init.php
****/

//加载文件 init.php

//开启权限控制
define('ACC',true);

//初始化
require('./include/init.php');
//+------------获取分类产品数组$categoods--开始!!-------------+
// 获取对应栏的cat_id;
$cat_id = isset($_GET['cat_id'])?$_GET['cat_id']+0:0;
$cat = new CateModel();
	//获取category表中的所有信息 $catlist
$catlist = $cat->select();
	// 获取'男士正装(cat_id=1)'对应的子孙目录树
$tree = $cat->getCatTree($catlist,$cat_id);
    //将$tree从数组转化成字符串,用','分割
foreach($tree as $v){
    $arr[] = $v['cat_id'];
}
$cat_str = implode(',',$arr);
    //从goods表中取出所有商品信息
$goods = new GoodsModel();
$data = $goods->select();
$categoods = $goods->getCateGoods($data,$cat_str);
$total = count($categoods);
// print_r($categoods);
/*
$tree:
Array([0] => Array(
            [cat_id] => 2
            [cat_name] => 西装
            [parent_id] => 1
            [intro] => 西装
            [lev] => 1
        )
        [1] => Array(
            [cat_id] => 3
            [cat_name] => 衬衫
            [parent_id] => 1
            [intro] => 衬衫
            [lev] => 1
        ))

$arr:
Array
(
    [0] => 2
    [1] => 3
)
$cat_str:
2,3
*/
// $newlist = $goods->getNew(5);
// print_r($newlist);exit;
// +--------获取分类产品数组$categoods--结束!!---------+
//取商品
$page = isset($_GET['page'])?$_GET['page']+0:1;
$perpage = 4 ;
$offset = ($page-1)*$perpage;
// echo $page,'&nbsp;',$perpage,'&nbsp;',$offset;
$categoods = $goods->getPageGoods($cat_id,$offset,$perpage);
// var_dump($categoods);

//分页
// +--------分页--开始!!---------+
// echo '$total =' ,$total,'$page = ',$page,'$perpage = ',$perpage;
//PageTool($total,$page,$perpage);
$pagetool = new PageTool($total,$page,$perpage);

// +--------分页--结束!!---------+
// include(ROOT.'view/front/lanmu.html');
$smarty->assign('categoods',$categoods);
$smarty->assign('total',$total);
$pt = $pagetool->show();
$smarty->assign('pt',$pt);
$smarty->display(ROOT.'view/front/lanmu.html');
?>