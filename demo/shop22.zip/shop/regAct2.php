<?php 
/****
测试 $bool = filter_var($value,FILTER_VALIDATE_EMAIL) !== false;
****/

define('ACC',true);
include('./include/init.php');

/*
接收email字段
使用filter_var函数过滤
输出
*/

$email = ($_POST['email']);
var_dump(filter_var($email,FILTER_VALIDATE_EcMAIL));

?>