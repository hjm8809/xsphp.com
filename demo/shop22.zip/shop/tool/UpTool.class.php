<?php 
/****
单文件上传类
多文件再扩展
****/



defined('ACC')||exit('ACC Denied');

/*
上传文件
配置允许的后缀 string $allowExt
配置允许的大小 float $maxSize

获取文件后缀 functino $getExt($file)
判断文件后缀 function isAllowExt($ext)

随机生成目录	
随机生成文件名

良好的报错支持
*/

/*
	func UpTool
	实现路径
	1)定义上传条件参数设置
		a.允许后缀
		b.允许大小
		c.报错代码(键值对)		
	2)各种错误提示函数编写
		a.允许后缀
	  	b.允许大小
	  	c.上传路径
	3)上传
		a.基础判断 $_FILES
		b.上传 	   $move_uploaded_file
		c.返回保存路径
*/
class UpTool{
	protected $allowExt = 'jpg,jpeg,gif,bmp,png';
	protected $maxSize = 1; //1M,M为单位
	protected $file = Null; //准备储存上传文件的信息用的
	protected $errno = 0;
	protected $error = array(
		0=>'上传过程很顺利,上传成功',
		1=>'上传中某单文件过大,上传失败',
		2=>'上传总文件过大,超出系统表单限制,上传失败',
		3=>'文件只有部分被上传,上传失败',
		4=>'没有文件被上传,上传失败',
		5=>'',
		6=>'找不到临时文件,上传失败',
		7=>'文件写入失败,上传失败',
		8=>"不允许上传的文件类型<br />仅允许以下文件类型:jpg,jpeg,gif,bmp,png",
		9=>'上传中某单文件过大,上传失败',
		10=>'创建目录失败',
		11=>'移动失败'
		);
	/*
PHP手册中$_FILES的报错机制设定
其值为 0，没有错误发生，文件上传成功。 
UPLOAD_ERR_INI_SIZE 其值为 1，上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值。 
UPLOAD_ERR_FORM_SIZE 其值为 2，上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值。 
UPLOAD_ERR_PARTIAL 其值为 3，文件只有部分被上传。 
UPLOAD_ERR_NO_FILE 其值为 4，没有文件被上传。 
UPLOAD_ERR_NO_TMP_DIR 其值为 6，找不到临时文件夹。PHP 4.3.10 和 PHP 5.0.3 引进。 
UPLOAD_ERR_CANT_WRITE 其值为 7，文件写入失败。PHP 5.1.0 引进。 
	*/
		
	/*
		上传开始
		函数:up
		作用:
		1)上传完成文件(保存到指定目录)
		2)返回文件目录(字符串)
	*/
		public function up($key){
			/*
			print_r($_FILES);
			Array(
				[pic]=>Array(
					[name]=>abc.jpg
					[type]=>abcxxx/xxxx
					[tmp_name]=>d:\wamp\***
					[error]=>0
					[size]=>497560					
				)
			)

			*/
			if(!isset($_FILES[$key])){
				echo '上传文件不存在';
			}
				$f = $_FILES[$key];
				// print_r($f);
				$this->errno =$f['error'];
				//获取后缀
				$ext =$this->getExt($f['name']);
				//检查后缀
				if(!$this->isAllowExt($ext)){
					$this->errno = 8;
					return false;
				}
				//检查大小
				if(!$this->isAllowSize($f['size'])){
					$this->errno = 9;
					return false;					
				}
				//创建目录
				if(!$dir = $this->mk_dir()){
					$this->errno = 10;
					return false;
				}
				//生成随机名
				$newname = $this->randName().'.'.$ext;
				//移动
				$dir = $dir.'/'.$newname;
				$move = move_uploaded_file($f['tmp_name'],$dir);
				if(!$move){
					$this->errno = 11;
					return false;
				}
				return str_replace(ROOT,'',$dir);
				
		}
	/*
		获取错误
	*/
		public function getErr(){
			return $this->error[$this->errno];
		}

	/*
		param $exts 允许后缀
		作用 使用此函数,将外界的 后缀值 赋给protedcd的后缀值
	*/
		public function setExt($exts){
			$this->allowExt = $exts;
		}

	/*
		param $num 允许大小(M)
		作用 使用此函数,将外界的参数,赋给protected的内部参数
	*/
		public function setSize($num){
			$this->maxSize = $num;
		}		

	/*
		param $string $file
		return $string $ext 后缀
	*/
	protected function getExt($file){
		$tmp = explode('.',$file);
		return end($tmp);
	}

	/*
		param  $string $ext 文件后缀
		return bool
	*/
	protected function isAllowExt($ext){
			$ext = strtolower($ext);
			$allowExt = strtolower($this->allowExt);
			$allowExt = explode(',',$allowExt);
			return in_array($ext,$allowExt);
	}

	protected function isAllowSize($size){
			if($size>($this->maxSize*1024*1024)){
				return false;
			}else{ return true; }
	}

	/*
		按日期创建目录
	*/

		protected function mk_dir(){			
			$dir = ROOT.'data/'.date('Ym/d');
			if(is_dir($dir) || mkdir($dir,0777,true)){
				return $dir;
			}else{
				return false;
			}

		}

	/*
		生成随机文件名
	*/
		protected function randName($lenght=6){
			$str = 'abcdefghijklmnopqrstuvwxyz0123456789';
			return substr(str_shuffle($str),0,$lenght);
		}
}

?>