<?php 
/****
file CarTool.class.php
作用 实现购物车功能
****/
/*
购物车类
分析购物车:
1:无论刷新了多少次页面,或多少个商品,
都要求你查看购物车里,看到的是一个一样的结果
即:你打开A商品刷新,B商品刷亲,首页,看到的购物车应该是一样的结果,即全局有效.

解决:把购物车的信息放在数据库,也可以放在session/cookie.

2:既然是全局有效,暗示,购物车的实例只能有1个!
一个客户只能有一个购物车

解决:单例模式

A.技术选型:session+单例
B.功能分析:
添加商品
删除商品
修改商品的数量_常用_数量加减一

查询购物车的商品种类
				数量
				总金额
				所有商品
清空购物车
*/

/*
	购物车类
	设定一个数组$item
	将产品信息存入$item,所有的CURD均操作数组
	简而言之:将对产品的操作,转换成对数组的操作
	实现路径:
	1)写CartTool的单例模式/防止继承/防止克隆
	2)写入SESSION['cart']
	3)创建数组$items
	4)针对$items分别写CURD方法
*/
class CartTool{
	private static $ins = null;
	private $items = array();//商品

	//单例模式
	final protected function __construct(){}//防止继承
	final protected function __clone(){}//防止克隆
	protected static function getIns(){
		if(!(self::$ins instanceof self)){
			self::$ins = new CartTool(); 
		}	return self::$ins;		
	}

	//把购物车的单例对象放到session里
	public static function getCart(){
		if(!isset($_SESSION['cart'])||!($_SESSION['cart'] instanceof self)){
				$_SESSION['cart'] = self::getIns();
		}
		return $_SESSION['cart'];
	}

	/*
	添加商品
		param int $id 商品主键
		param string $name 商品名称
		param float $price 商品价格
		param int $num 购买数量
	*/
	public function addItem($id,$name,$price,$num=1){
		if($this->hasItem($id)){//如果该商品已经存在,则直接加数量
			$this->incNum($id,$num);
			return;
		}
		$items = array();
		$items['name'] = $name;
		$items['price'] = $price;
		$items['num'] = $num;
		$this->items[$id]=$items;
	}
	/*
		修改购物车中的商品数量
		param int $id 商品主键
		parame int $num 商品数量
	*/
	public function modNum($id,$num=1){
		if(!$this->hasItem($id)){
			return false;
		}
		$this->items[$id]['num'] = $num;
	}
	/*
		商品数量加一
	*/
	public function incNum($id,$num=1){
		if($this->hasItem($id)){
			$this->items[$id]['num'] +=$num;
		}
	}
	/*
		商品数量减一
		如果减少到数量为0,则从购物车删除
	*/
	public function decNum($id,$num=1){
		if($this->hasItem($id)){
				$this->items[$id]['num'] -=$num;
		}
	//如果商品数量=0,则删除商品
		if($this->items[$id]['num']==0){
			$this->delItem($id);
		}		
	}

	/*
		删除商品
	*/
		public function delItem($id){
			unset($this->items[$id]);
		}
	/*
		查询购物车商品种类
	*/
		public function getCat(){
			return count($this->items);
		}
	/*
		查询购物车中的商品个数
	*/
		public function getNum(){
			if($this->getCat()==0){
				return 0;
			}

			$sum = 0;
			foreach($this->items as $v){
				$sum += $v['num'];
			}return $sum;
		}
	/*
		查询购物车商品的总金额
	*/
	public function getPrice(){
		if($this->getCat()==0){
				return 0;
			}
		$price = 0;
		foreach($this->items as $v){
			$price += $v['num']*$v['price'];
		}return $price;
	}
	/*
		查询购物车中的所有商品
	*/
	public function all(){
		return $this->items;
	}
	/*
		判断某商品是否存在
		param int $id 商品主键
	*/
	public function hasItem($id){
		return array_key_exists($id,$this->items);
	}

	/*
		清空购物车
	*/
	public function clear(){
		$this->items = array();
	}

}

// $cart = CartTool::getCart();
// if(isset($_GET['test'])&&$_GET['test'] == 'add'){
// 	$cart->addItem(1,'王八',23.4,1);
// 	echo 'add OK';
// }else if(isset($_GET['test'])&&$_GET['test'] == 'clear'){
// 	$cart->clear();
// 	echo 'clear ok';
// }else if($_GET)
// else{
// 	print_r($cart);
// }
/*
测试部份
+-----------------------------+
if(!isset($_GET['test'])){
	$_GET['test'] = 'unset';
}
switch($_GET['test']){
	case 'addwb':
	$cart->addItem(1,'王八',23.4,1);
	echo 'addwb OK';
	break;
	case 'addfz':
	$cart->addItem(2,'方舟',10000,1);
	echo 'addfz ok';
	break;
	case 'clear':
	$cart->clear();
	echo 'clear ok';
	break;
	case 'show':
	print_r($cart->all());
	echo '<br />';
	echo '共', $cart->getCat() ,'种', $cart->getNum() ,'件商品';
	echo '<br />';
	echo '共', $cart->getPrice() ,'元';


	// default:
	// print_r($cart); 
}
+-----------------------------------+
*/
// print_r(CartTool::getCart());
?>