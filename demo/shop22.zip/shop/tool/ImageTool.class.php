<?php 
/****
图片处理类
A.加水印
B.缩略图
****/

class ImageTool{

/*
	fun imageInfo
	作用 分析图片的信息
	实现路径
	1)基础判断
	2)获取图片信息
	3)将信息赋给数组并返回
	param string $image //文件路径(含文件名)
	return array() //返回图片[长宽/类型]数组
*/
	protected function imageInfo($image){
		//判断图片是否存在
		if(!file_exists($image)){
			echo'图片不存在';
			return false;
		}

		$info = getimagesize($image);
		if ($info == false){
			echo'!getimagesize($image)';
			return false;
		}
		//此时info分析出来是一个数组
		$img['width'] = $info['0'];
		$img['height'] = $info['1'];
		$img['ext'] = substr($info['mime'],strpos($info['mime'],'/')+1);

		return $img;
		/*
		print_r($img):
		Array(
			   	[width] => 600
			    [height] => 392
			    [ext] => jpeg
			 )
		*/
	} 

	/*
		加水印功能
		实现路径:
		1)基础判断
		2)将原图与水图读取到内存
		3)按一定规则合并两图
		4)保存合并的的图
		5)返回保存结果 bool

		核心函数 imagecopymerge — 拷贝并合并图像的一部分
		bool imagecopymerge ( resource $dst_im , resource $src_im , int $dst_x , int $dst_y , int $src_x , int $src_y , int $src_w , int $src_h , int $pct )

		param String $dst 待操作图片
		param String $water 加水印后的图片
		param String $save 不填则默认替换原始图
		return bool & 保存图片

	*/
	public static function water($dst,$water,$save=NULL,$alpha=50,$pos=NULL){
		//保证两个图片均存在
		if(!file_exists($dst)||!file_exists($water)){
			echo'!保证两个图片均存在';
			return false;
		}
		//首选保证等加水印图片尺寸 < 水印尺寸
		$dinfo = self::imageInfo($dst);
		$winfo = self::imageInfo($water);
		if($winfo['width']>$dinfo['width'] || $winfo['height']>$dinfo['height']){
			echo'水印过大';
			return false;
		}
		//两张图片都需要读到画面上,但图片类型不确定,用什么函数来读?
		$dfunc = 'imagecreatefrom'.$dinfo['ext'];
		$wfunc = 'imagecreatefrom'.$winfo['ext'];
		if(!function_exists($dfunc) || !function_exists($wfunc)){
			echo "$dfunc 或者 $wfunc 不存在";
			return false;
		}
		//动态加载画面
		$dim = $dfunc($dst);
		$wim = $wfunc($water);
		//根据水印位置,计算粘贴的坐标
		switch ($pos) {
			case '0'://左上角
				$posx = 0;
				$posy = 0;
				break;
			
			case'1'://右上角
				$posx = $dinfo['width']-$winfo['width'];
				$posy = 0;
				break;
			case'2'://左下角
				$posx = 0;
				$posy = $dinfo['height']-$winfo['height'];
				break;
			default:
				$posx = $dinfo['width']-$winfo['width'];
				$posy = $dinfo['height']-$winfo['height'];

		}

		//加水印
		imagecopymerge($dim,$wim,$posx,$posy,0,0,$winfo['width'],$winfo['height'],$alpha);
		//保存
		if($save == NULL){
			$save =$dst;
			unlink($dst);//删除原图
		}
		$createfunc = 'image'.$dinfo['ext'];
		$createfunc($dim,$save);
		imagedestroy($dim);
		imagedestroy($wim);
		return true;
	}

	/*
		thumb 生成缩略图
		实现路径:
		1)基础判断
		2)将原图读到内存
		3)(按缩略图尺寸)创建空白画面并填充白色
		4)使用函数imagecopyresampled()形成缩略图,并保存
		5)返回执行结果 bool

		核心函数 imagecopyresampled — 重采样拷贝部分图像并调整大小
		bool imagecopyresampled ( resource $dst_image , resource $src_image , int $dst_x , int $dst_y , int $src_x , int $src_y , int $dst_w , int $dst_h , int $src_w , int $src_h )

		等比例缩放/两边留白
		param String $dst原图路径
			  String $save 缩略图保存路径
			  int $width 缩略图宽
			  int $height 缩略图高
		retrun bool
	*/
	public static function thumb($dst,$save,$width='200',$height='200'){
		//保存路径
		$save=self::mk_dir().self::randName().".jpg";
		// var_dump($save);die;
		// $save = "../data/201410/20/thumb/aaa.jpg";
		//判断待处理图片$dst是否存在?
		$dinfo = self::imageInfo($dst);
		if($dinfo==false){
			echo "$dst 不存在";
			return false;
		}
		//计算缩略比例,按比例展现原图
		$calc = min($width/$dinfo['width'],$height/$dinfo['height']);
		$twidth = $dinfo['width']*$calc;//缩略后的宽
		$theight = $dinfo['height']*$calc;//缩略后的高
		//创建画面
		$dfunc = 'imagecreatefrom'.$dinfo['ext'];
		$dim = $dfunc($dst);
		//创建缩略图画面
		$tim = imagecreatetruecolor($width,$height);
		//创建白色填充缩略画面
		$white = imagecolorallocate($tim,255,255,255);
		//填充缩略图画面
		imagefill($tim,0,0,$white);
		//复制并缩略
		//图片留白居中
		$paddingx = ($width-$twidth)/2;
		$paddingy = ($height-$theight)/2;
		imagecopyresampled($tim,$dim,$paddingx,$paddingy,0,0,$twidth,$theight,$dinfo['width'],$dinfo['height']);
		// imagecopyresampled($tim,$dim,$paddingx,$paddingy,0,0,$width,$height,$twidth,$theight);
		// imagecopyresampled(dst_image, src_image, dst_x, dst_y, src_x, src_y, dst_w, dst_h, src_w, src_h)
		//保存图片
		/*
		if(!$save){
			$save = $dst;
			unlink($dst);
		}
		*/
		$createfunc = 'image'.$dinfo['ext'];
		// echo 'image'.$dinfo['ext'];die;//输出 imagejpeg
		// var_dump($tim);die;
		
		// imagejpeg($tim,$save);
		if($createfunc($tim,$save)){
			return str_replace(ROOT,'',$save);
		}else{
			return flase;
		}
		/*
		echo 'tim='.$tim.'<br />';
		echo 'dim='.$dim.'<br />';
		echo 'paddingx='.$paddingx.'<br />';
		echo 'paddingy='.$paddingy.'<br />';
		echo 'width='.$width.'<br />';
		echo 'height='.$height.'<br />';
		echo 'dinfo[\'width\']='.$dinfo['width'].'<br />';
		echo 'dinfo[\'height\']='.$dinfo['height'].'<br />';
		*/
	}


	public static function thumb_goods($dst,$save,$width='300',$height='400'){
		//保存路径
		$save=self::mk_dir('thumb_goods').self::randName('thumb_goods').".jpg";
		// var_dump($save);die;
		// $save = "../data/201410/20/thumb/aaa.jpg";
		//判断待处理图片$dst是否存在?
		$dinfo = self::imageInfo($dst);
		if($dinfo==false){
			echo "$dst 不存在";
			return false;
		}
		//计算缩略比例,按比例展现原图
		$calc = min($width/$dinfo['width'],$height/$dinfo['height']);
		$twidth = $dinfo['width']*$calc;//缩略后的宽
		$theight = $dinfo['height']*$calc;//缩略后的高
		//创建画面
		$dfunc = 'imagecreatefrom'.$dinfo['ext'];
		$dim = $dfunc($dst);
		//创建缩略图画面
		$tim = imagecreatetruecolor($width,$height);
		//创建白色填充缩略画面
		$white = imagecolorallocate($tim,255,255,255);
		//填充缩略图画面
		imagefill($tim,0,0,$white);
		//复制并缩略
		//图片留白居中
		$paddingx = ($width-$twidth)/2;
		$paddingy = ($height-$theight)/2;
		imagecopyresampled($tim,$dim,$paddingx,$paddingy,0,0,$twidth,$theight,$dinfo['width'],$dinfo['height']);
		// imagecopyresampled($tim,$dim,$paddingx,$paddingy,0,0,$width,$height,$twidth,$theight);
		// imagecopyresampled(dst_image, src_image, dst_x, dst_y, src_x, src_y, dst_w, dst_h, src_w, src_h)
		//保存图片
		/*
		if(!$save){
			$save = $dst;
			unlink($dst);
		}
		*/
		$createfunc = 'image'.$dinfo['ext'];
		// echo 'image'.$dinfo['ext'];die;//输出 imagejpeg
		// var_dump($tim);die;
		
		// imagejpeg($tim,$save);
		if($createfunc($tim,$save)){
			return str_replace(ROOT,'',$save);
		}else{
			return flase;
		}
		/*
		echo 'tim='.$tim.'<br />';
		echo 'dim='.$dim.'<br />';
		echo 'paddingx='.$paddingx.'<br />';
		echo 'paddingy='.$paddingy.'<br />';
		echo 'width='.$width.'<br />';
		echo 'height='.$height.'<br />';
		echo 'dinfo[\'width\']='.$dinfo['width'].'<br />';
		echo 'dinfo[\'height\']='.$dinfo['height'].'<br />';
		*/
	}
		/*
		按日期创建目录
	*/

		protected function mk_dir($img = 'thumb'){
			//传入参数为thumb
			if($img == 'thumb'){
			$dir = ROOT.'data/'.date('Ym/d').'/thumb/';
			//传入参数为goods
			}else if($img == 'thumb_goods'){
			$dir = ROOT.'data/'.date('Ym/d').'/thumb_goods/';
			}else{
				return false;
			}			
			if(is_dir($dir) || mkdir($dir,0777,true)){
				return $dir;
			}else{
				return false;
			}

		}

	/*
		生成随机文件名
	*/
		protected function randName($img = 'thumb',$lenght=6){
			$str = 'abcdefghijklmnopqrstuvwxyz0123456789';
			if($img == 'thumb'){
			return substr(str_shuffle($str),0,$lenght)."_thumb";
		}else if ($img == 'thumb_goods'){
			return substr(str_shuffle($str),0,$lenght)."_thumb_goods";
		}else{
			return false;
		}
		}
}

// echo 'hello';
/*
$imageTool = new ImageTool();
var_dump($imageTool);
var_dump($imageTool->imageInfo('222.jpeg'));
*/
?>