<?php 
/****
file PageTool.class.php
作用 分页
fun show($total,$page=false,$perpage=false)
param $total 总页数
	  $page=false 当前页
	  $perpage=false 每页条数
return string $nav //[1]2[3][4][5],带超链接
****/
/*
总结:
分页原理:
A.三个变量
B.两个公式

	A:三个变量
		1)总条数: $total
		2)每页条数: $perpage
		3)当前页: $page

	B:两个公式
		1)总页数 $cnt = ceil($total/$perpage);//相除,进一
		2)第$page页,显示第几条到第几条?
		答:第$page页,说明前面已经跑过了$page-1页,每页又是$perpage条
		跳过了($page-1)*$perpage+1条开始取,取$perpage条
		故是第($page-1)*$perpage+1至$page*$perpage
*/
defined('ACC')||exit('ACC Denied');

/*
	class
*/
class PageTool{
	protected $total = 0;
	protected $perpage =10;
	protected $page =1 ;

	public function __construct($total,$page=false,$perpage=false){
		$this->total = $total;
		if($page){
			$this->page = $page;
		}
		if($perpage){
			$this->perpage=$perpage;
		}
	}

	// 主要函数,创建分页导航
	public function show(){
/*
	实现路径
	1)定义三个变量/总页数/当前页/每页页数
	2)计算总页数,当前面的条号偏移量
	3)循环,拼凑
*/
		//取整,得到总页数
		$cnt = ceil($this->total/$this->perpage);
		$uri = ($_SERVER['REQUEST_URI']);
		$parse = parse_url($uri);
		//$parse = Array ( [path] => /shop/tool/pagetool.class.php [query] => id=222&xx=33&page2=5 ) 
		$param = array();
		if(isset($parse['query'])){
		parse_str($parse['query'],$param);
		//返回:$param=Array ( [id] => 222 [xx] => 33 [page2] => 5 ) 
		}
		//不管$param数组里,有没有page单元,都unset一下,确保没有page单元
		//即保存除page之外的所有单元
		unset($param['page']);
		$url = $parse['path'].'?';
		if(!empty($param)){
		$param = http_build_query($param);
		$url = $url.$param.'&';
		}
		// echo $url;die;
		//下一个关键,就是计算页码导航
		$nav = array();
		$nav[] = '<span class="page_now">'.$this->page.'</span>';
// ===调试===开始===
/*
		echo 'total='.$this->total;
		echo '<br />';
		echo 'perpage='.$this->perpage;
		echo '<br />';
		echo 'page='.$this->page;
		echo '<br />';
		echo 'cnt='.$cnt;		
*/
// ===调试===结束===

		for($left=$this->page-1,$right=$this->page+1;($left>=1 || $right<=$cnt)&&count($nav)<=4;){
			$ll='<a href ="'.$url.'page='.$left.'" >['.$left.']</a>';
			$rr='<a href ="'.$url.'page='.$right.'" >['.$right.']</a>';
			if($left>=1){
			array_unshift($nav,$ll);
			$left -= 1;
			}
			if($right<=$cnt){
			array_push($nav,$rr);
			$right += 1;
			}
		}
	  // print_r($nav);
	  return implode('',$nav);

	}

}
//<span class="page_now">1</span>
// <a href ="#" ><span class="page_now"> $this->page </span></a>
// $ll='<a href ="#" ><span class="page_now">'.$left.'</span></a>';


// +----测试---+


/*
$p = new PageTool(100,$_GET['page'],3);
echo $p->show();
//分页类应用
new pagetool(总条数,当前面,每页条数);
show()返回分页代码;
*/

?>
