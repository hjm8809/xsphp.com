<?php 
/****
所有由用户直接访问到的这些页面,
都必须加载init.php
userlist.php  用户列表页
****/

//加载文件 init.php  conf.class.php
require('./include/init.php');


$test = new TestModel();
$list = $test->select();
print_r($list);
var_dump($list);

?> 